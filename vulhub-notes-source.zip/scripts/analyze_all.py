# -*- coding: utf-8 -*-
"""Analyze all 268 notes: classify coverage, component normalization, id collisions."""
import os
import re
from urllib.parse import unquote

REPO = '/home/z/my-project/repo_ref'


def classify(title: str) -> str:
    t = title
    if '反序列化' in t:
        return '反序列化漏洞'
    if 'SQL注入' in t or 'SQL 注入' in t or 'SQLi' in t:
        return 'SQL注入'
    if 'XXE' in t or 'XML外部实体' in t or 'XML 实体' in t:
        return 'XXE注入'
    if 'SSRF' in t:
        return 'SSRF'
    if any(k in t for k in ('路径穿越', '目录穿越', '目录遍历', '文件读取', '文件包含', '任意文件删除', '任意文件读取')):
        return '路径穿越/文件读取'
    if any(k in t for k in ('文件上传', '文件写入', '写文件')):
        return '文件上传/写入'
    if any(k in t for k in ('认证绕过', '权限绕过', '未授权', '身份验证绕过', '身份认证绕过', '权限提升', '提权', '默认密钥', '默认口令', '默认密码')):
        return '认证绕过/提权'
    if '弱口令' in t:
        return '弱口令'
    if any(k in t for k in ('信息泄露', '敏感信息', '心脏出血', '用户名枚举')):
        return '信息泄露'
    if any(k in t for k in ('解析漏洞', '文件名逻辑')):
        return '解析漏洞'
    if any(k in t for k in ('远程代码执行', '远程命令执行', '命令执行', '代码执行', 'RCE', 'getshell',
                            '命令注入', '代码注入', '表达式注入', '模板注入', 'JNDI', '后门', '沙盒绕过', '破壳',
                            'SSTI', '代码执行漏洞', 'GetShell')):
        return '远程命令执行'
    return '其他'


# sidebar parse
comp_map = {}
current = None
for line in open(os.path.join(REPO, '_sidebar.md'), encoding='utf-8'):
    line = line.strip()
    m = re.match(r'^\*\s+\*\*(.+?)\*\*', line)
    if m:
        current = m.group(1).strip()
        continue
    m2 = re.search(r'\]\((vulhub/[^)]+\.md)\)', line)
    if m2 and current:
        fname = unquote(m2.group(1)[len('vulhub/'):])
        comp_map[fname] = current

# iterate all files
others = []
comps = {}
no_cve = 0
years = set()
id_seen = {}
collisions = []
files = sorted(f for f in os.listdir(os.path.join(REPO, 'vulhub')) if f.endswith('.md'))
print('total md files:', len(files))
for f in files:
    title = f[:-3]
    path = os.path.join(REPO, 'vulhub', f)
    raw = open(path, encoding='utf-8').read()
    cves = re.findall(r'CVE-\d{4}-\d{4,7}', raw[:400]) or re.findall(r'CVE-\d{4}-\d{4,7}', raw)
    seen, cves_u = set(), []
    for c in cves:
        if c not in seen:
            seen.add(c)
            cves_u.append(c)
    if not cves_u:
        no_cve += 1
    else:
        years.add(int(cves_u[0].split('-')[1]))
    if len(cves_u) == 1:
        sid = cves_u[0].lower()
    else:
        sid = 'vXX'
    if sid in id_seen:
        collisions.append((sid, id_seen[sid], title))
    id_seen[sid] = title
    comp = comp_map.get(f, '??')
    comps[comp] = comps.get(comp, 0) + 1
    ty = classify(title)
    if ty == '其他':
        others.append((comp, title))

print('no-cve notes:', no_cve, '| year range:', min(years), '-', max(years))
print('unique components:', len(comps))
print('id collisions (same-CVE titles):', len(collisions))
for c in collisions:
    print('   *', c)
print('\n=== OTHER bucket (%d) ===' % len(others))
for comp, t in others:
    print('  [%s] %s' % (comp, t))
