# -*- coding: utf-8 -*-
"""Parse ALL Vulhub vulnerability notes (268) into structured JSON for the new website.

v2: full migration (previously curated 61 only).
- iterate _sidebar.md in original order (component groups) → stable `no` ordering
- normalize messy component headers (S2-xxx → Struts2, PHP family → PHP, vendor strip...)
- extend classification (XSS / 逻辑配置 / 拒绝服务 / 综合渗透 buckets)
- id strategy: unique single-CVE → cve-xxxx-xxxxx; duplicates → -2 suffix; otherwise v{no:03d}
"""
import json
import os
import re
from urllib.parse import unquote

REPO = '/home/z/my-project/repo_ref'
OUT = '/home/z/my-project/public/data/vulns.json'

FEATURED = {
    'Apache Log4j2 lookup JNDI 注入漏洞（CVE-2021-44228）',
    'Apache Shiro 1.2.4反序列化漏洞（CVE-2016-4437）',
    'fastjson 1.2.24 反序列化导致任意命令执行漏洞',
    'Weblogic 管理控制台未授权远程命令执行漏洞（CVE-2020-14882，CVE-2020-14883）',
    'S2-045 远程代码执行漏洞（CVE-2017-5638）',
    'Spring框架Data Binding与JDK 9+导致的远程代码执行漏洞（CVE-2022-22965）',
    'Apache Tomcat AJP 文件包含漏洞（CVE-2020-1938）',
    'Redis 4.x5.x 主从复制导致的命令执行',
    'OpenSSL 心脏出血漏洞（CVE-2014-0160）',
    'Polkit pkexec权限提升漏洞（CVE-2021-4034）',
    'Drupal Drupalgeddon 2 远程代码执行漏洞（CVE-2018-7600）',
    'PHP-CGI远程代码执行漏洞（CVE-2012-1823）',
}

# ---------------- component normalization ----------------
COMP_ALIASES = {
    'WebLogic': 'Weblogic',
    'Couchdb': 'CouchDB',
    'Imagetragick': 'ImageMagick',
    'Discuz!X': 'Discuz',
    'Metabase任意文件读取漏洞': 'Metabase',
    'Metabase未授权JDBC远程代码执行漏洞': 'Metabase',
    'Jumpserver随机数种子泄露导致账户劫持漏洞': 'Jumpserver',
    'Openfire管理后台认证绕过漏洞': 'Openfire',
    'DNS域传送漏洞': 'DNS',
    'CVE-2022-22978：RegexRequestMatcher': 'Spring Security',
    'Rocket': 'Rocket Chat',
    'MinIO集群模式信息泄露漏洞': 'MinIO',
}
PHP_FAMILY = {'PHP', 'PHP-CGI远程代码执行漏洞', 'PHP-FPM', 'PHP文件包含漏洞', 'PHP环境', 'PHP利用GNU'}
VENDOR_PREFIXES = ('Apache ', 'Alibaba ', 'Atlassian ', 'Adobe ')
KEEP_FULL = {'Apache HTTP Server'}  # stripping would produce a meaningless name


def normalize_comp(comp: str, title: str) -> str:
    if comp in COMP_ALIASES:
        return COMP_ALIASES[comp]
    # all S2-xxx one-note headers belong to Struts2
    if re.match(r'^S2-\d', comp):
        return 'Struts2'
    if comp in PHP_FAMILY:
        return 'PHP'
    # derive product name from title for strays like "PHP-CGI远程代码执行漏洞"
    if comp in PHP_FAMILY:
        return 'PHP'
    if comp in KEEP_FULL:
        return comp
    for p in VENDOR_PREFIXES:
        if comp.startswith(p) and comp != p.strip():
            return comp[len(p):].strip()
    return comp


# ---------------- vulnerability classification ----------------
def classify(title: str) -> str:
    t = title.replace('\u2013', '-').replace('\u2014', '-')
    if '反序列化' in t:
        return '反序列化漏洞'
    if 'XSS' in t or '跨站脚本' in t:
        return 'XSS跨站脚本'
    if 'SQL注入' in t or 'SQL 注入' in t or 'NoSQL注入' in t or 'MongoDB 注入' in t or 'SQLi' in t:
        return 'SQL注入'
    if 'XXE' in t or 'XML外部实体' in t or 'XML 实体' in t:
        return 'XXE注入'
    if 'SSRF' in t:
        return 'SSRF'
    if 'DOS漏洞' in t or '拒绝服务' in t or 'DoS' in t or 'DDoS' in t or 'DDOS' in t:
        return '拒绝服务'
    if any(k in t for k in ('路径穿越', '目录穿越', '目录遍历', '文件读取', '文件包含', '任意文件删除',
                            '任意文件读取', 'Local File Inclusion', '本地文件包含')):
        return '路径穿越/文件读取'
    if any(k in t for k in ('文件上传', '文件写入', '写文件', '任意文件读写', 'ZipSlip')):
        return '文件上传/写入'
    if any(k in t for k in ('认证绕过', '权限绕过', '未授权', '身份验证绕过', '身份认证绕过', '权限提升',
                            '提权', '默认密钥', '默认口令', '默认密码', '任意用户登录', '授权绕过')):
        return '认证绕过/提权'
    if '弱口令' in t:
        return '弱口令'
    if any(k in t for k in ('信息泄露', '敏感信息', '心脏出血', '用户名枚举', '随机数种子', '越界读取')):
        return '信息泄露'
    if any(k in t for k in ('解析漏洞', '文件名逻辑')):
        return '解析漏洞'
    if any(k in t for k in ('远程代码执行', '远程命令执行', '命令执行', '代码执行', 'RCE', 'getshell',
                            'GetShell', '命令注入', '代码注入', '表达式注入', '模板注入', 'SSTI',
                            'JNDI', '后门', '沙盒绕过', '破壳', '环境变量注入', 'webshell', 'WebShell')):
        return '远程命令执行'
    if any(k in t for k in ('URL跳转', '开放注册', '账户劫持', '配置错误', '域传送', 'HTTPoxy')):
        return '逻辑/配置错误'
    if '渗透测试环境' in t or '常规渗透' in t:
        return '综合渗透'
    return '其他'


def main():
    # 1. sidebar → ordered [(filename, component)] in original document order
    entries = []  # (fname, component)
    current = None
    with open(os.path.join(REPO, '_sidebar.md'), encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            m = re.match(r'^\*\s+\*\*(.+?)\*\*', line)
            if m:
                current = m.group(1).strip()
                continue
            m2 = re.search(r'\]\((vulhub/[^)]+\.md)\)', line)
            if m2 and current:
                entries.append((unquote(m2.group(1)[len('vulhub/'):]), current))

    # 2. parse each note
    records = []
    missing = []
    for fname, comp in entries:
        title = fname[:-3]
        path = os.path.join(REPO, 'vulhub', fname)
        if not os.path.exists(path):
            missing.append(fname)
            continue
        with open(path, encoding='utf-8') as f:
            raw = f.read()

        cve_src = raw[:400].replace('\u2013', '-').replace('\u2014', '-')
        if not re.findall(r'CVE-\d{4}-\d{4,7}', cve_src):
            cve_src = raw.replace('\u2013', '-').replace('\u2014', '-')
        cves = re.findall(r'CVE-\d{4}-\d{4,7}', cve_src)
        seen, cves_u = set(), []
        for c in cves:
            if c not in seen:
                seen.add(c)
                cves_u.append(c)
        year = int(cves_u[0].split('-')[1]) if cves_u else None

        component = normalize_comp(comp, title)
        if component == 'Struts2' and not title.startswith('S2'):
            pass  # keep title as-is, only component grouping
        # strip duplicated leading H1 (equals title) for cleaner detail page
        content = raw
        first = re.match(r'^#\s+(.+?)\s*\n', content)
        if first and first.group(1).strip() == title.strip():
            content = content[first.end():]
        content = content.strip()

        records.append({
            'title': title,
            'component': component,
            'cves': cves_u,
            'year': year,
            'type': classify(title),
            'featured': title in FEATURED,
            'images': content.count('!['),
            'codeBlocks': len(re.findall(r'```', content)) // 2,
            'content': content,
        })

    # 3. stable ids: unique single-CVE → cve slug; dup → -2 suffix; else v{no:03d}
    used: dict = {}
    for i, r in enumerate(records, 1):
        if len(r['cves']) == 1:
            base = r['cves'][0].lower()
        else:
            base = 'v%03d' % i
        n = used.get(base, 0)
        r['id'] = base if n == 0 else '%s-%d' % (base, n + 1)
        used[base] = n + 1
        r['no'] = i

    # 4. aggregate
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    types = sorted({v['type'] for v in records},
                   key=lambda t: (-sum(1 for v in records if v['type'] == t), t))
    comps: dict = {}
    for v in records:
        comps[v['component']] = comps.get(v['component'], 0) + 1
    data = {
        'generatedAt': '2026-10-04',
        'source': 'https://github.com/hacker369/VulhubTutorialNotes.github.io',
        'total': len(records),
        'types': types,
        'components': sorted(comps.items(), key=lambda x: (-x[1], x[0])),
        'vulns': [
            {k: v[k] for k in ('id', 'no', 'title', 'component', 'cves', 'year', 'type',
                               'featured', 'images', 'codeBlocks', 'content')}
            for v in records
        ],
    }
    with open(OUT, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)

    size = os.path.getsize(OUT) / 1024
    print('OK total=%d, missing=%d, size=%.0fKB' % (len(records), len(missing), size))
    if missing:
        print('MISSING:')
        for m in missing:
            print('  -', m)
    print('TYPES (%d):' % len(types))
    for t in types:
        print('  %-14s %d' % (t, sum(1 for v in records if v['type'] == t)))
    print('COMPONENTS: %d' % len(comps))
    leftovers = [v['title'] for v in records if v['type'] == '其他']
    print('其他 leftover (%d):' % len(leftovers))
    for t in leftovers:
        print('  -', t)
    # id sanity
    ids = [v['id'] for v in records]
    assert len(ids) == len(set(ids)), 'DUPLICATE IDS!'
    print('id uniqueness OK; sample ids:', ids[:3], '...', ids[-2:])


if __name__ == '__main__':
    main()
