'use client';

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { VulnsData, Route, LibraryQuery, Vuln } from '@/lib/types';
import type { Lang } from '@/lib/i18n';

interface AppState {
  /** 远程数据 */
  data: VulnsData | null;
  loading: boolean;
  error: string | null;
  loadData: () => Promise<void>;

  /** 界面语言（localStorage 持久化） */
  lang: Lang;
  setLang: (l: Lang) => void;

  /** 哈希路由 */
  route: Route;
  setRoute: (r: Route) => void;

  /** 阅读进度（localStorage 持久化） */
  read: string[];
  fav: string[];
  toggleRead: (id: string) => void;
  toggleFav: (id: string) => void;
  markRead: (id: string) => void;

  /** 图片灯箱 */
  lightbox: string | null;
  setLightbox: (url: string | null) => void;
}

/* ---------------- 哈希路由解析 / 序列化 ---------------- */

export function parseHash(hash: string): Route {
  const raw = hash.replace(/^#\/?/, '');
  if (raw.startsWith('vuln/')) {
    const id = decodeURIComponent(raw.slice('vuln/'.length));
    if (id) return { name: 'vuln', id };
  }
  if (raw.startsWith('guide')) {
    return { name: 'guide' };
  }
  if (raw.startsWith('library')) {
    const query: LibraryQuery = { q: '', type: '', comp: '', status: '' };
    const qs = raw.split('?')[1];
    if (qs) {
      const sp = new URLSearchParams(qs);
      query.q = sp.get('q') ?? '';
      query.type = sp.get('type') ?? '';
      query.comp = sp.get('comp') ?? '';
      const s = sp.get('status') ?? '';
      query.status = (['read', 'unread', 'fav'].includes(s) ? s : '') as LibraryQuery['status'];
    }
    return { name: 'library', query };
  }
  return { name: 'home' };
}

export function routeToHash(r: Route): string {
  if (r.name === 'home') return '#/';
  if (r.name === 'guide') return '#/guide';
  if (r.name === 'library') {
    const sp = new URLSearchParams();
    if (r.query.q) sp.set('q', r.query.q);
    if (r.query.type) sp.set('type', r.query.type);
    if (r.query.comp) sp.set('comp', r.query.comp);
    if (r.query.status) sp.set('status', r.query.status);
    const qs = sp.toString();
    return qs ? `#/library?${qs}` : '#/library';
  }
  return `#/vuln/${encodeURIComponent(r.id)}`;
}

export function navigate(r: Route) {
  if (typeof window !== 'undefined') {
    window.location.hash = routeToHash(r).slice(1);
  }
}

/* ---------------- Store ---------------- */

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      data: null,
      loading: false,
      error: null,
      loadData: async () => {
        if (get().data || get().loading) return;
        set({ loading: true, error: null });
        try {
          const res = await fetch('./data/vulns.json');
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          const data: VulnsData = await res.json();
          set({ data, loading: false });
        } catch (e) {
          set({ error: e instanceof Error ? e.message : '加载数据失败', loading: false });
        }
      },

      lang: 'zh',
      setLang: (l) => set({ lang: l }),

      route: { name: 'home' },
      setRoute: (r) => set({ route: r }),

      read: [],
      fav: [],
      toggleRead: (id) =>
        set((s) => ({
          read: s.read.includes(id) ? s.read.filter((x) => x !== id) : [...s.read, id],
        })),
      markRead: (id) =>
        set((s) => (s.read.includes(id) ? s : { read: [...s.read, id] })),
      toggleFav: (id) =>
        set((s) => ({
          fav: s.fav.includes(id) ? s.fav.filter((x) => x !== id) : [...s.fav, id],
        })),

      lightbox: null,
      setLightbox: (url) => set({ lightbox: url }),
    }),
    {
      name: 'vulhub-notes-progress',
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ read: s.read, fav: s.fav, lang: s.lang }) as unknown as AppState,
    }
  )
);

/* ---------------- 派生工具 ---------------- */

export function filterVulns(
  vulns: Vuln[],
  query: LibraryQuery,
  read: string[],
  fav: string[],
  typeLabel: (t: string) => string = (t) => t
): Vuln[] {
  const q = query.q.trim().toLowerCase();
  return vulns.filter((v) => {
    if (query.type && v.type !== query.type) return false;
    if (query.comp && v.component !== query.comp) return false;
    if (query.status === 'fav' && !fav.includes(v.id)) return false;
    if (query.status === 'read' && !read.includes(v.id)) return false;
    if (query.status === 'unread' && read.includes(v.id)) return false;
    if (q) {
      const hay = `${v.title} ${v.component} ${v.type} ${typeLabel(v.type)} ${v.cves.join(' ')}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}
