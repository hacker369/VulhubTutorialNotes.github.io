/** 新人必读指南内容（基于仓库 README.md 扩写，中英双语） */
export const GUIDE_ZH = `# 新人必读 · Vulhub 靶场复现入门指南

> 本指南基于作者实战踩坑经验整理而成，覆盖从零搭建环境 → 复现第一个漏洞 → 日常维护与镜像清理的完整流程。配合本站 268 篇图文复现笔记使用，效果最佳。

## 一、什么是 Vulhub？

Vulhub 是一个开源漏洞靶场项目，它把每个已知漏洞都封装成了独立的 docker-compose 环境——**不需要自己编译部署漏洞组件，一条 \`docker compose up -d\` 就能一键拉起真实漏洞环境**，开箱即用。

它非常适合已经掌握 Linux 基础、想动手练渗透的网安萌新：

- **省心**：不用折腾繁琐的环境搭建，把时间花在漏洞本身；
- **真实**：组件都是真实业务软件（Weblogic、Tomcat、Redis……），与实战几乎一致；
- **案例全**：靶场持续更新，覆盖反序列化、RCE、SQL 注入、认证绕过等各大类型。

作者在刷靶场时也遇到过各种奇奇怪怪的问题，都是边搜索资料边解决的，最后整理成了本站的 268 篇图文笔记：每篇都记录**环境搭建、漏洞原理、完整复现步骤与利用链分析**，跟着做就能通关。

## 二、复现前的准备

### 1. 硬件与系统要求

| 项目 | 建议配置 |
| --- | --- |
| 系统 | Ubuntu 20.04+ / Debian / CentOS 7+（Windows 走 WSL2，Mac 用 Docker Desktop） |
| 内存 | ≥ 4GB（Weblogic、Confluence 等大型环境建议 8GB） |
| 磁盘 | ≥ 40GB 可用空间（镜像拉多了很占地方，第七节有清理方法） |
| 网络 | 能访问 Docker Hub（国内服务器建议配置镜像加速，见第三节） |

### 2. 基础知识

- Linux 常用命令（cd、cat、grep、chmod 等）；
- 端口与 HTTP 协议的基本概念；
- 会用浏览器 F12 开发者工具；
- 建议再装一个 **Burp Suite**，抓包分析请求必备。

## 三、安装 Docker 与 Docker Compose

### 1. 一键安装（推荐）

\`\`\`bash
# 官方脚本安装，国外/国内服务器均可用
curl -fsSL https://get.docker.com | sh

# 启动 Docker 并设置开机自启
sudo systemctl enable --now docker
\`\`\`

### 2. 验证安装

\`\`\`bash
docker version            # 查看 Docker 版本
docker compose version    # Compose v2（推荐，注意中间是空格）
docker-compose --version  # Compose v1（旧版，中间是横杠）
\`\`\`

> 💡 老教程里的 \`docker-compose\`（横杠）是 v1，新版 Docker 自带 Compose v2 插件（\`docker compose\`，空格）。两者在本站笔记中完全等效，用哪个都行。

### 3. 配置镜像加速（国内强烈建议）

编辑 \`/etc/docker/daemon.json\`（没有就新建）：

\`\`\`json
{
  "registry-mirrors": [
    "https://docker.m.daocloud.io",
    "https://dockerproxy.net"
  ]
}
\`\`\`

重启 Docker 生效：

\`\`\`bash
sudo systemctl restart docker
\`\`\`

## 四、启动你的第一个靶场环境

以本站精选的 Log4j2（CVE-2021-44228）为例：

\`\`\`bash
# 1. 克隆 Vulhub 仓库
git clone https://github.com/vulhub/vulhub.git
cd vulhub

# 2. 进入要复现的漏洞目录（目录名 = 组件 / CVE 编号）
cd log4j2/CVE-2021-44228

# 3. 一键启动环境（首次运行会自动拉取镜像，耐心等待）
docker compose up -d

# 4. 查看环境状态与端口映射
docker compose ps
\`\`\`

\`docker compose ps\` 输出中的 \`0.0.0.0:8983->8080/tcp\` 表示：**浏览器访问 \`http://<你的IP>:8983\` 即可打开靶场**（宿主机端口 -> 容器端口）。

复现完成后销毁环境：

\`\`\`bash
docker compose down -v   # -v 表示同时删除数据卷
\`\`\`

> ⚠️ 建议每复现完一个漏洞就销毁对应环境，既省内存也省磁盘。

## 五、配合本站笔记的高效复现流程

1. **找笔记**：在漏洞库搜索 CVE 编号或组件名；
2. **读原理**：先看笔记开头的漏洞背景与利用链分析，别上来就抄命令；
3. **起环境**：按第四节拉起对应环境；
4. **跟着复现**：按笔记步骤操作，每一步截图记录；
5. **抓包思考**：用 Burp 观察每个请求的 Payload，理解「为什么能打」；
6. **进阶**：尝试自己写 POC 脚本（Python requests 就够用）；
7. **收尾**：\`docker compose down -v\` 销毁环境，回站内点「已读」，进度自动保存。

## 六、Docker 常用命令速查

| 命令 | 作用 |
| --- | --- |
| \`docker compose up -d\` | 后台启动当前目录的靶场环境 |
| \`docker compose ps\` | 查看容器状态与端口映射 |
| \`docker compose logs -f\` | 实时查看日志（环境起不来先看这个） |
| \`docker compose down -v\` | 停止并销毁环境（含数据卷） |
| \`docker exec -it <容器> bash\` | 进入容器内部排查 |
| \`docker images\` | 查看已拉取的镜像 |
| \`docker ps -a\` | 查看所有容器（含已停止） |
| \`docker system df\` | 查看 Docker 磁盘占用 |

## 七、镜像清理与磁盘管理（重要！）

学习过程中会不断拉取镜像，磁盘迟早告急——作者在实际刷洞时就经常遇到空间不足。这里整理一套清理方案。

### 1. 清理不用的容器、镜像与数据卷（日常方案）

\`\`\`bash
# 首先进入你的 vulhub 目录下
cd vulhub

# 停止并删除所有容器
docker-compose down -v

# 删除所有未使用的镜像、容器、网络和数据卷
docker system prune -a -f
docker volume prune -f
\`\`\`

> ⚠️ \`docker system prune -a\` 会删掉**所有未被容器使用的镜像**，下次复现需要重新拉取。这是磁盘空间与时间的取舍，空间紧张时果断执行。

### 2. 查看占用，精准清理

\`\`\`bash
docker system df         # 看 Docker 到底占了多少空间
docker rmi <镜像ID>      # 删除指定镜像
\`\`\`

### 3. 彻底卸载 Docker（仅当不再需要时）

删除 Vulhub 的文件和目录（假设克隆在 /path/to/vulhub）：

\`\`\`bash
rm -rf /path/to/vulhub
\`\`\`

卸载 Docker（以 CentOS 为例）：

\`\`\`bash
sudo yum remove docker docker-client docker-client-latest docker-common \\
  docker-latest docker-latest-logrotate docker-logrotate docker-engine
\`\`\`

卸载 Docker Compose（v1 二进制安装的）：

\`\`\`bash
sudo rm /usr/local/bin/docker-compose
\`\`\`

清理残留数据和配置文件：

\`\`\`bash
sudo rm -rf /var/lib/docker
sudo rm -rf /etc/docker
sudo rm -rf /etc/systemd/system/docker.service.d
sudo rm -rf /var/run/docker.sock
\`\`\`

重启系统以确保所有更改生效：

\`\`\`bash
sudo reboot
\`\`\`

## 八、常见问题 FAQ

**Q1：端口被占用，环境起不来？**
先用 \`docker compose ps\` 检查是否有旧容器残留，\`docker compose down -v\` 清掉再启动；若是宿主机其他程序占了端口，用 \`lsof -i:端口号\` 找到进程，或修改 \`docker-compose.yml\` 中的端口映射。

**Q2：拉取镜像很慢 / 超时？**
配置第三节的镜像加速；也可以先 \`docker pull\` 手动把镜像拉下来，再 \`up -d\`。

**Q3：提示 \`docker-compose: command not found\`？**
说明你的 Docker 只带了 Compose v2，改用 \`docker compose up -d\`（空格版）即可。

**Q4：Windows / Mac 能玩吗？**
可以。Windows 建议开启 WSL2 + Docker Desktop；Mac 直接装 Docker Desktop（Apple Silicon 对部分 x86 镜像较慢或需加 \`--platform linux/amd64\`）。

**Q5：环境起不来 / 特别卡？**
先 \`docker compose logs -f\` 看日志；检查内存是否充足（Weblogic 启动要吃好几 GB）；再不行 \`sudo systemctl restart docker\` 后重试。

**Q6：复现进度会丢吗？**
不会。本站的「已读」「收藏」保存在浏览器 localStorage 中，随时回来接着刷。

**Q7：还有什么省心技巧？**
虚拟机里玩的话，装完 Docker 后**打一个快照**——环境玩崩了一键还原，比重装系统快得多。

## 九、法律与安全声明

- 所有复现操作请**只在本地虚拟机或自己拥有授权的环境**中进行，严禁对任何未授权目标（尤其是公网资产）使用；
- 靶场组件包含**真实漏洞**，切勿把靶场端口直接暴露到公网——云服务器务必配置好安全组；
- 本站所有内容仅供网络安全学习、教学与研究使用，请勿用于非法用途。
`;

export const GUIDE_EN = `# Starter Guide · Vulhub Walkthrough 101

> Compiled from the author's hands-on trial and error, this guide covers everything from a zero-state machine to your first exploit, plus day-to-day maintenance and image cleanup. Best read together with the 268 illustrated notes on this site.

## 1. What is Vulhub?

Vulhub is an open-source collection of pre-built vulnerable environments. Every known vulnerability is packaged as an isolated docker-compose project — **no manual compiling or deploying required: a single \`docker compose up -d\` boots a real, exploitable environment**.

It is ideal for security beginners who know basic Linux and want hands-on practice:

- **Effortless**: skip the tedious environment building and focus on the vulnerability itself;
- **Realistic**: components are real products (Weblogic, Tomcat, Redis...) just like in the wild;
- **Rich**: constantly updated, covering deserialization, RCE, SQL injection, auth bypass and more.

The author hit all kinds of weird issues while clearing the range and solved them one by one — the lessons became the 268 illustrated notes on this site. Each note documents **environment setup, vulnerability background, the full exploitation walkthrough and chain analysis**.

## 2. Before You Start

### 1. Hardware & OS requirements

| Item | Recommendation |
| --- | --- |
| OS | Ubuntu 20.04+ / Debian / CentOS 7+ (Windows: WSL2, macOS: Docker Desktop) |
| RAM | ≥ 4GB (8GB recommended for heavy environments like Weblogic / Confluence) |
| Disk | ≥ 40GB free (images pile up quickly — see Section 7 for cleanup) |
| Network | Access to Docker Hub (mainland users: configure a registry mirror, see Section 3) |

### 2. Background knowledge

- Basic Linux commands (cd, cat, grep, chmod...);
- Basic understanding of TCP ports and HTTP;
- Browser DevTools (F12);
- **Burp Suite** is strongly recommended for intercepting requests.

## 3. Install Docker & Docker Compose

### 1. One-line install (recommended)

\`\`\`bash
# Official install script
curl -fsSL https://get.docker.com | sh

# Start Docker and enable it on boot
sudo systemctl enable --now docker
\`\`\`

### 2. Verify the installation

\`\`\`bash
docker version            # Docker engine version
docker compose version    # Compose v2 (recommended, note the space)
docker-compose --version  # Compose v1 (legacy, note the dash)
\`\`\`

> 💡 Legacy tutorials use \`docker-compose\` (with a dash, v1). Modern Docker ships the Compose v2 plugin (\`docker compose\`, with a space). Both are interchangeable throughout the notes on this site.

### 3. Configure a registry mirror (strongly recommended in mainland China)

Edit \`/etc/docker/daemon.json\` (create it if missing):

\`\`\`json
{
  "registry-mirrors": [
    "https://docker.m.daocloud.io",
    "https://dockerproxy.net"
  ]
}
\`\`\`

Then restart Docker:

\`\`\`bash
sudo systemctl restart docker
\`\`\`

## 4. Launch Your First Environment

Using Log4j2 (CVE-2021-44228) as an example:

\`\`\`bash
# 1. Clone the Vulhub repository
git clone https://github.com/vulhub/vulhub.git
cd vulhub

# 2. Enter the target directory (component / CVE ID)
cd log4j2/CVE-2021-44228

# 3. Start the environment (first run pulls images automatically)
docker compose up -d

# 4. Check container status and port mapping
docker compose ps
\`\`\`

In the \`docker compose ps\` output, \`0.0.0.0:8983->8080/tcp\` means **open \`http://<your-ip>:8983\` in your browser** (host port -> container port).

When you are done, destroy the environment:

\`\`\`bash
docker compose down -v   # -v also removes volumes
\`\`\`

> ⚠️ Destroy each environment right after finishing it — it saves both memory and disk.

## 5. Recommended Workflow with This Site

1. **Find the note**: search the library by CVE ID or component;
2. **Read the theory**: study the background & chain analysis first — do not just copy commands;
3. **Boot the environment** as shown in Section 4;
4. **Follow along**: replicate step by step and screenshot everything;
5. **Intercept & think**: inspect every payload in Burp and understand *why* it works;
6. **Level up**: write your own POC script (plain Python requests is enough);
7. **Wrap up**: \`docker compose down -v\`, then mark the note as read — progress is saved automatically.

## 6. Docker Command Cheat Sheet

| Command | Purpose |
| --- | --- |
| \`docker compose up -d\` | Start the environment in the current directory |
| \`docker compose ps\` | Show containers and port mappings |
| \`docker compose logs -f\` | Stream logs (check this first if something fails) |
| \`docker compose down -v\` | Stop and destroy the environment (incl. volumes) |
| \`docker exec -it <ctr> bash\` | Shell into a container |
| \`docker images\` | List pulled images |
| \`docker ps -a\` | List all containers (incl. stopped) |
| \`docker system df\` | Show Docker disk usage |

## 7. Image Cleanup & Disk Management (Important!)

You will keep pulling images as you learn, and disk space will run out eventually — the author ran into this constantly. Here is a proven cleanup playbook.

### 1. Remove unused containers, images & volumes (routine)

\`\`\`bash
# Enter your vulhub directory first
cd vulhub

# Stop and remove all containers
docker-compose down -v

# Remove all unused images, containers, networks and volumes
docker system prune -a -f
docker volume prune -f
\`\`\`

> ⚠️ \`docker system prune -a\` removes **every image not currently used by a container** — you will have to re-pull them next time. Trade time for space, and run it decisively when disk runs low.

### 2. Inspect usage and target the big ones

\`\`\`bash
docker system df         # How much disk does Docker actually use?
docker rmi <image-id>    # Remove a specific image
\`\`\`

### 3. Fully uninstall Docker (only if you no longer need it)

Delete the Vulhub files (assuming it was cloned to /path/to/vulhub):

\`\`\`bash
rm -rf /path/to/vulhub
\`\`\`

Uninstall Docker (CentOS example):

\`\`\`bash
sudo yum remove docker docker-client docker-client-latest docker-common \\
  docker-latest docker-latest-logrotate docker-logrotate docker-engine
\`\`\`

Uninstall Docker Compose (v1 binary install):

\`\`\`bash
sudo rm /usr/local/bin/docker-compose
\`\`\`

Remove leftover data and configuration:

\`\`\`bash
sudo rm -rf /var/lib/docker
sudo rm -rf /etc/docker
sudo rm -rf /etc/systemd/system/docker.service.d
sudo rm -rf /var/run/docker.sock
\`\`\`

Reboot to make sure everything takes effect:

\`\`\`bash
sudo reboot
\`\`\`

## 8. FAQ

**Q1: Port already in use / environment fails to start?**
Run \`docker compose ps\` for leftovers, clean them with \`docker compose down -v\`, then start again. If another host process owns the port, find it with \`lsof -i:<port>\` or change the mapping in \`docker-compose.yml\`.

**Q2: Image pulls are slow / timing out?**
Configure the registry mirror from Section 3, or pre-pull with \`docker pull\` before \`up -d\`.

**Q3: \`docker-compose: command not found\`?**
Your Docker only ships Compose v2 — use \`docker compose up -d\` (space) instead.

**Q4: Can I do this on Windows / macOS?**
Yes. On Windows enable WSL2 + Docker Desktop; on macOS install Docker Desktop (Apple Silicon may be slow with x86 images or need \`--platform linux/amd64\`).

**Q5: Environment crashes / is very slow?**
Check \`docker compose logs -f\`; verify free memory (Weblogic alone eats several GB); try \`sudo systemctl restart docker\`.

**Q6: Will I lose my reading progress?**
No. "Read" marks and favorites are stored in your browser's localStorage.

**Q7: Any pro tips?**
If you work inside a VM, **take a snapshot** right after installing Docker — a broken environment is then one click away from a clean slate.

## 9. Legal & Security Notice

- Reproduce vulnerabilities **only on local VMs or systems you are explicitly authorized to test** — never against unauthorized targets, especially public-facing assets;
- The environments contain **real vulnerabilities**: never expose them to the internet; configure cloud security groups properly;
- All content on this site is for security learning, teaching and research only.
`;
