'use client';

import { useAppStore } from '@/lib/store';

/** 站点语言 */
export type Lang = 'zh' | 'en';

/** 中英文 UI 文案字典 */
export const STRINGS = {
  zh: {
    /* 导航 / 通用 */
    navHome: '首页',
    navLibrary: '漏洞库',
    navGuide: '新人必读',
    progress: '进度',
    switchLang: 'EN',
    footerBuiltPre: 'Vulhub 漏洞复现 · 基于',
    footerBuiltPost: '重新构建',
    footerLegal: '⚠ 内容仅用于网络安全学习与研究 · 请勿用于非法用途',
    /* 首页 Hero */
    heroTitle1: '渗透测试靶场',
    heroTitle2a: '漏洞复现',
    heroTitle2b: ' 通关笔记',
    heroDesc:
      '全量收录 {total} 篇 Vulhub 靶场复现笔记，覆盖 Struts2、PHP、Spring、Weblogic、Django 等 {comps} 个组件、{cves} 个 CVE。每篇均包含环境搭建、漏洞复现、利用链分析的完整图文记录。',
    ctaLibrary: '进入漏洞库',
    ctaFeatured: '精选经典漏洞',
    ctaGuide: '新人必读',
    badgeNotes: '{n} 篇笔记',
    badgeComps: '{n} 个组件',
    badgeIllustrated: '图文复现',
    /* 首页新人 Banner */
    bannerTitle: '第一次打靶场？先读「新人必读」',
    bannerText:
      '不知道怎么装 Docker、拉镜像、启动靶场环境？指南带你从零开始：环境搭建 → 复现第一个漏洞 → 清理镜像释放磁盘，10 分钟跑通全流程。',
    bannerCta: '立即阅读指南',
    bannerTags: ['环境搭建', '常用命令', '镜像清理', '常见问题'],
    /* 首页统计 */
    statsNotes: '漏洞笔记',
    statsNotesUnit: '篇',
    statsCves: 'CVE 编号',
    statsCvesUnit: '个',
    statsComps: '覆盖组件',
    statsCompsUnit: '个',
    statsProgress: '刷洞进度',
    statsProgressSuffix: '/{n} 篇',
    /* 首页图表 */
    typeDistTitle: '// 漏洞类型分布',
    typeDistHint: ' 点击筛选',
    yearDistTitle: '// 收录年份',
    yearHint: '点击柱状图按年份搜索 · {n} 篇无 CVE 编号漏洞未计入',
    /* 首页区块 */
    featuredTitle: '精选经典漏洞',
    featuredSub: '高频靶场 / 面试必刷',
    viewAll: '全部漏洞',
    compTitle: '按组件浏览',
    compCount: '{n} 个组件',
    expandAll: '展开全部 {n} 个',
    collapseComps: '收起组件',
    favHint: '已收藏 {n} 篇 · 在漏洞库中点击「收藏」筛选可快速查看',
    /* 漏洞库 */
    libTitle: '漏洞库',
    libDesc: '{n} 篇漏洞复现笔记 · 支持关键词 / CVE 编号 / 组件 / 漏洞类型检索',
    searchPh: '搜索漏洞名称、CVE 编号、组件（如 shiro / CVE-2021-44228 / log4j）...',
    allTypes: '全部类型',
    allComps: '全部组件',
    stAll: '全部',
    stUnread: '未读',
    stRead: '已读',
    stFav: '收藏',
    clearFilters: '清除筛选',
    resultsUnit: '篇',
    noMatch: '没有匹配的漏洞笔记',
    noMatchHint: '试试其他关键词，或清除筛选条件',
    resetFilters: '重置筛选',
    /* 详情页 */
    classicBadge: '经典',
    codeBlocksUnit: '{n} 个代码块',
    shotsUnit: '{n} 张截图',
    minRead: '≈ {n} 分钟阅读',
    markRead: '标记已读',
    alreadyRead: '已读',
    favBtn: '收藏',
    favedBtn: '已收藏',
    shareBtn: '分享',
    copiedBtn: '已复制',
    copyCodeBtn: '复制',
    copiedCodeBtn: '已复制',
    backTop: '回到顶部',
    tocTitle: '本页目录',
    tocLoading: '加载中...',
    relatedTitle: '// 同组件其他漏洞 · ',
    prevLabel: '← 上一篇',
    nextLabel: '下一篇 →',
    notFound: '未找到该漏洞笔记',
    notFoundId: '未找到该漏洞笔记（id: {id}）',
    backLibrary: '返回漏洞库',
    zhOnlyNote: '本笔记为中文原文，暂无英文翻译。配合浏览器翻译或按 PoC 命令跟做即可。',
    /* 漏洞卡片 */
    noCve: '无 CVE 编号',
    /* 页面骨架 / 错误 */
    errTitle: '数据加载失败',
    retry: '重新加载',
    skeletonText: 'loading vulnerability notes ...',
    /* 新人必读页 */
    guideEyebrow: '// STARTER GUIDE · READ ME FIRST',
    guideTitle: '新人必读 · 靶场复现入门指南',
    guideSub: '从安装 Docker 到复现你的第一个漏洞，再到镜像清理与常见坑位 —— 基于作者的实战踩坑经验整理。',
    guideMeta: '{n} 分钟读完 · 中英双语',
    guideEnNote: '268 篇漏洞笔记正文为中文原文，本指南提供中英双语。',
    guideCta: '浏览漏洞库',
  },
  en: {
    navHome: 'Home',
    navLibrary: 'Library',
    navGuide: 'Starter Guide',
    progress: 'Progress',
    switchLang: '中文',
    footerBuiltPre: 'Vulhub Walkthrough Notes · Rebuilt from',
    footerBuiltPost: '',
    footerLegal: '⚠ For security learning & research only · Never use for illegal purposes',
    heroTitle1: 'Pentest Range',
    heroTitle2a: 'Vulhub',
    heroTitle2b: ' Walkthrough Notes',
    heroDesc:
      'A full collection of {total} Vulhub walkthrough notes covering {comps} components (Struts2, PHP, Spring, Weblogic, Django and more) with {cves} CVEs. Every note documents environment setup, exploitation steps and chain analysis with screenshots.',
    ctaLibrary: 'Enter the Library',
    ctaFeatured: 'Featured Classics',
    ctaGuide: 'Starter Guide',
    badgeNotes: '{n} notes',
    badgeComps: '{n} components',
    badgeIllustrated: 'illustrated',
    bannerTitle: 'New to Vulhub? Read the Starter Guide first',
    bannerText:
      "Not sure how to install Docker, pull images or launch a vulnerable environment? The guide walks you through the whole workflow: setup → your first exploit → image cleanup, all in about 10 minutes.",
    bannerCta: 'Read the guide now',
    bannerTags: ['Setup', 'Commands', 'Cleanup', 'FAQ'],
    statsNotes: 'Vuln Notes',
    statsNotesUnit: '',
    statsCves: 'CVE IDs',
    statsCvesUnit: '',
    statsComps: 'Components',
    statsCompsUnit: '',
    statsProgress: 'Progress',
    statsProgressSuffix: '/{n}',
    typeDistTitle: '// Vuln Types',
    typeDistHint: ' click to filter',
    yearDistTitle: '// Publication Years',
    yearHint: 'Click a bar to search by year · {n} notes without a CVE are not included',
    featuredTitle: 'Featured Classic Vulns',
    featuredSub: 'high-frequency targets / interview must-practice',
    viewAll: 'All vulns',
    compTitle: 'Browse by Component',
    compCount: '{n} components',
    expandAll: 'Show all {n}',
    collapseComps: 'Collapse',
    favHint: '{n} favorites · use the "Fav" filter in the library to find them',
    libTitle: 'Vulnerability Library',
    libDesc: '{n} walkthrough notes · search by keyword / CVE ID / component / vuln type',
    searchPh: 'Search by title, CVE, component (e.g. shiro / CVE-2021-44228 / log4j)...',
    allTypes: 'All types',
    allComps: 'All components',
    stAll: 'All',
    stUnread: 'Unread',
    stRead: 'Read',
    stFav: 'Fav',
    clearFilters: 'Clear filters',
    resultsUnit: '',
    noMatch: 'No matching notes',
    noMatchHint: 'Try other keywords, or clear the filters',
    resetFilters: 'Reset filters',
    classicBadge: 'Classic',
    codeBlocksUnit: '{n} code blocks',
    shotsUnit: '{n} screenshots',
    minRead: '≈ {n} min read',
    markRead: 'Mark as read',
    alreadyRead: 'Read',
    favBtn: 'Fav',
    favedBtn: 'Faved',
    shareBtn: 'Share',
    copiedBtn: 'Copied',
    copyCodeBtn: 'Copy',
    copiedCodeBtn: 'Copied',
    backTop: 'Top',
    tocTitle: 'On this page',
    tocLoading: 'Loading...',
    relatedTitle: '// More in ',
    prevLabel: '← Previous',
    nextLabel: 'Next →',
    notFound: 'Note not found',
    notFoundId: 'Note not found (id: {id})',
    backLibrary: 'Back to library',
    zhOnlyNote: 'Note bodies are written in Chinese (original content). Follow the PoC commands directly or use your browser translator.',
    noCve: 'No CVE',
    errTitle: 'Failed to load data',
    retry: 'Retry',
    skeletonText: 'loading vulnerability notes ...',
    guideEyebrow: '// STARTER GUIDE · READ ME FIRST',
    guideTitle: 'Starter Guide · Vulhub 101',
    guideSub: 'From installing Docker to your first exploit, image cleanup and common pitfalls — based on hard-won hands-on experience.',
    guideMeta: '{n} min read · bilingual (EN/ZH)',
    guideEnNote: 'The 268 vuln notes are written in Chinese; this guide is bilingual.',
    guideCta: 'Browse the Library',
  },
};

export type Strings = (typeof STRINGS)['zh'];

/** 简单模板替换：'{n} 篇' + {n: 3} → '3 篇' */
export function fmt(tpl: string, vars: Record<string, string | number> = {}): string {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? `{${k}}`));
}

/** 漏洞类型英文名（筛选 chips / 徽章显示用；数据 key 保持中文不变） */
export const TYPE_NAMES_EN: Record<string, string> = {
  '远程命令执行': 'RCE',
  '反序列化漏洞': 'Deserialization',
  '认证绕过/提权': 'Auth Bypass / Privesc',
  '路径穿越/文件读取': 'Path Traversal / File Read',
  '文件上传/写入': 'File Upload / Write',
  'SQL注入': 'SQL Injection',
  '信息泄露': 'Info Disclosure',
  'SSRF': 'SSRF',
  '解析漏洞': 'Parser Bug',
  '逻辑/配置错误': 'Logic / Misconfiguration',
  'XSS跨站脚本': 'XSS',
  'XXE注入': 'XXE Injection',
  '弱口令': 'Weak Credentials',
  '拒绝服务': 'Denial of Service',
  '综合渗透': 'Full Pentest',
  '其他': 'Other',
};

export function typeName(type: string, lang: Lang): string {
  if (lang === 'en') return TYPE_NAMES_EN[type] ?? type;
  return type;
}

/** 读取当前语言文案的 hook（跟随全局语言状态） */
export function useT(): Strings {
  return useAppStore((s) => STRINGS[s.lang]);
}
