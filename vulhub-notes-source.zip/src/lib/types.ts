/** 漏洞笔记数据结构 */
import type { Lang } from '@/lib/i18n';

export interface Vuln {
  id: string;
  no: number;
  title: string;
  component: string;
  cves: string[];
  year: number | null;
  type: string;
  featured: boolean;
  images: number;
  codeBlocks: number;
  content: string;
}

export interface VulnsData {
  generatedAt: string;
  source: string;
  total: number;
  types: string[];
  components: [string, number][];
  vulns: Vuln[];
}

export interface LibraryQuery {
  q: string;
  type: string;
  comp: string;
  status: '' | 'read' | 'unread' | 'fav';
}

export type Route =
  | { name: 'home' }
  | { name: 'library'; query: LibraryQuery }
  | { name: 'guide' }
  | { name: 'vuln'; id: string };

/** 漏洞类型配色（暗黑黑客风） */
export const TYPE_COLORS: Record<string, { fg: string; bg: string; border: string }> = {
  '远程命令执行': { fg: '#f87171', bg: 'rgba(248,113,113,0.08)', border: 'rgba(248,113,113,0.35)' },
  '反序列化漏洞': { fg: '#fbbf24', bg: 'rgba(251,191,36,0.08)', border: 'rgba(251,191,36,0.35)' },
  '认证绕过/提权': { fg: '#c084fc', bg: 'rgba(192,132,252,0.08)', border: 'rgba(192,132,252,0.35)' },
  '路径穿越/文件读取': { fg: '#22d3ee', bg: 'rgba(34,211,238,0.08)', border: 'rgba(34,211,238,0.35)' },
  '文件上传/写入': { fg: '#f472b6', bg: 'rgba(244,114,182,0.08)', border: 'rgba(244,114,182,0.35)' },
  'SQL注入': { fg: '#fb923c', bg: 'rgba(251,146,60,0.08)', border: 'rgba(251,146,60,0.35)' },
  'XXE注入': { fg: '#a3e635', bg: 'rgba(163,230,53,0.08)', border: 'rgba(163,230,53,0.35)' },
  'SSRF': { fg: '#2dd4bf', bg: 'rgba(45,212,191,0.08)', border: 'rgba(45,212,191,0.35)' },
  '信息泄露': { fg: '#facc15', bg: 'rgba(250,204,21,0.08)', border: 'rgba(250,204,21,0.35)' },
  '弱口令': { fg: '#94a3b8', bg: 'rgba(148,163,184,0.08)', border: 'rgba(148,163,184,0.35)' },
  '解析漏洞': { fg: '#34d399', bg: 'rgba(52,211,153,0.08)', border: 'rgba(52,211,153,0.35)' },
  '逻辑/配置错误': { fg: '#60a5fa', bg: 'rgba(96,165,250,0.08)', border: 'rgba(96,165,250,0.35)' },
  'XSS跨站脚本': { fg: '#e879f9', bg: 'rgba(232,121,249,0.08)', border: 'rgba(232,121,249,0.35)' },
  '拒绝服务': { fg: '#64748b', bg: 'rgba(100,116,139,0.08)', border: 'rgba(100,116,139,0.35)' },
  '综合渗透': { fg: '#38bdf8', bg: 'rgba(56,189,248,0.08)', border: 'rgba(56,189,248,0.35)' },
  '其他': { fg: '#8b949e', bg: 'rgba(139,148,158,0.08)', border: 'rgba(139,148,158,0.35)' },
};

export function typeColor(type: string) {
  return TYPE_COLORS[type] ?? TYPE_COLORS['其他'];
}

export interface TerminalLine {
  prompt: boolean;
  text: string;
}

/** 首页 Terminal 打字脚本（按真实数据 + 语言动态生成） */
export function buildTerminalLines(
  total: number,
  compCount: number,
  yearMin: number,
  yearMax: number,
  cveCount: number,
  lang: Lang = 'zh'
): TerminalLine[] {
  if (lang === 'en') {
    return [
      { prompt: true, text: 'vulhub-notes --init' },
      { prompt: false, text: '[✓] Loading vuln knowledge base ... done' },
      { prompt: false, text: `[✓] Parsing ${cveCount} CVE IDs & 15 vuln types ... done` },
      { prompt: true, text: 'vulhub-notes --status' },
      { prompt: false, text: `notes: ${total} | components: ${compCount} | years: ${yearMin} - ${yearMax}` },
      { prompt: false, text: 'status: ready_for_hacking ∎' },
    ];
  }
  return [
    { prompt: true, text: 'vulhub-notes --init' },
    { prompt: false, text: '[✓] 加载漏洞知识库 ... done' },
    { prompt: false, text: `[✓] 解析 ${cveCount} 个 CVE 编号与 15 种漏洞类型 ... done` },
    { prompt: true, text: 'vulhub-notes --status' },
    { prompt: false, text: `笔记: ${total} 篇 | 组件: ${compCount} 个 | 年份: ${yearMin} - ${yearMax}` },
    { prompt: false, text: '状态: ready_for_hacking ∎' },
  ];
}
