'use client';

import { useEffect } from 'react';
import { ShieldAlert } from 'lucide-react';
import { parseHash, useAppStore } from '@/lib/store';
import { useT } from '@/lib/i18n';
import { Navbar, Footer } from '@/components/site/navbar';
import { HomeView } from '@/components/site/home-view';
import { ListView } from '@/components/site/list-view';
import { DetailView } from '@/components/site/detail-view';
import { GuideView } from '@/components/site/guide-view';

function Skeleton() {
  const t = useT();
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-12">
      <div className="mb-10 h-64 animate-pulse rounded-2xl border border-[#21262d] bg-[#161b22]" />
      <div className="mb-10 grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="h-28 animate-pulse rounded-xl border border-[#21262d] bg-[#161b22]" />
        ))}
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
          <div key={i} className="h-44 animate-pulse rounded-xl border border-[#21262d] bg-[#161b22]" />
        ))}
      </div>
      <p className="mt-8 text-center font-mono text-[12px] text-[#8b949e]">
        <span className="text-[#00ff9c]">➜</span> loading vulnerability notes ...
      </p>
    </div>
  );
}

function ErrorState({ msg, retry }: { msg: string; retry: () => void }) {
  const t = useT();
  return (
    <div className="mx-auto flex max-w-lg flex-col items-center px-4 py-28 text-center">
      <ShieldAlert className="mb-4 h-10 w-10 text-[#f87171]" />
      <p className="font-mono text-[14px] text-[#c9d4de]">{t.errTitle}</p>
      <p className="mt-2 font-mono text-[12px] text-[#8b949e]">{msg}</p>
      <button
        type="button"
        onClick={retry}
        className="mt-6 rounded-lg border border-[#00ff9c]/40 bg-[#00ff9c]/5 px-5 py-2 text-[13px] text-[#00ff9c] transition-colors hover:bg-[#00ff9c]/12"
      >
        {t.retry}
      </button>
    </div>
  );
}

export default function Page() {
  const route = useAppStore((s) => s.route);
  const setRoute = useAppStore((s) => s.setRoute);
  const data = useAppStore((s) => s.data);
  const loading = useAppStore((s) => s.loading);
  const error = useAppStore((s) => s.error);
  const loadData = useAppStore((s) => s.loadData);
  const lightbox = useAppStore((s) => s.lightbox);
  const setLightbox = useAppStore((s) => s.setLightbox);

  /* 初始化：数据 + 哈希路由 */
  useEffect(() => {
    loadData();
    const applyHash = () => setRoute(parseHash(window.location.hash));
    applyHash();
    window.addEventListener('hashchange', applyHash);
    return () => window.removeEventListener('hashchange', applyHash);
  }, [loadData, setRoute]);

  /* 路由切换回顶部（详情页内部自行处理） */
  useEffect(() => {
    if (route.name !== 'vuln') window.scrollTo({ top: 0 });
  }, [route]);

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />

      <main className="flex-1">
        {error ? (
          <ErrorState msg={error} retry={() => loadData()} />
        ) : loading && !data ? (
          <Skeleton />
        ) : !data ? (
          <Skeleton />
        ) : route.name === 'home' ? (
          <HomeView />
        ) : route.name === 'library' ? (
          <ListView query={route.query} />
        ) : route.name === 'guide' ? (
          <GuideView />
        ) : (
          <DetailView id={route.id} />
        )}
      </main>

      <Footer />

      {/* 图片灯箱（全局） */}
      {lightbox && (
        <div className="lightbox-overlay" onClick={() => setLightbox(null)} role="dialog" aria-label="查看大图">
          <img src={lightbox} alt="漏洞复现大图" referrerPolicy="no-referrer" />
        </div>
      )}
    </div>
  );
}
