import { NextResponse } from "next/server";

/* 纯静态 GET 响应，保证 output: "export" 时可被静态导出 */
export const dynamic = "force-static";

export async function GET() {
  return NextResponse.json({ message: "Hello, world!" });
}