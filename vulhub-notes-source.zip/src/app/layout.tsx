import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import "./site.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Vulhub 漏洞复现 | 渗透测试靶场通关笔记",
  description:
    "Vulhub 渗透测试靶场通关笔记与漏洞知识库：全量收录 268 篇漏洞复现教程，附带新人必读入门指南（Docker 环境搭建、镜像清理、常见问题，中英双语），覆盖 129 个组件、194 个 CVE，支持中英文界面切换、搜索与分类筛选。",
  keywords: [
    "Vulhub",
    "漏洞复现",
    "渗透测试",
    "靶场通关",
    "新人教程",
    "Docker 靶场",
    "CVE",
    "安全学习",
    "Log4j2",
    "Shiro",
    "Fastjson",
    "Weblogic",
    "Struts2",
    "Spring",
  ],
  authors: [{ name: "hacker369" }],
  openGraph: {
    title: "Vulhub 漏洞复现 · 渗透测试靶场通关笔记",
    description: "全量收录 268 篇 Vulhub 靶场漏洞复现笔记 + 新人必读入门指南 · 中英双语",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#0d1117",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" className="dark" suppressHydrationWarning>
      <head>
        {/* 语雀 CDN 图片防盗链：不发送 referrer */}
        <meta name="referrer" content="no-referrer" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen flex flex-col`}
      >
        {children}
      </body>
    </html>
  );
}
