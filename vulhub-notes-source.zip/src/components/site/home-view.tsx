'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowRight, BookOpen, ChevronRight, ChevronDown, Cpu, FileText, Fingerprint, Layers, Star } from 'lucide-react';
import { navigate, useAppStore } from '@/lib/store';
import { buildTerminalLines, typeColor, type TerminalLine } from '@/lib/types';
import { useT, fmt, typeName } from '@/lib/i18n';
import { VulnCard } from '@/components/site/vuln-card';

/** 带 {var} 占位符的文案 → 高亮数字 JSX（可指定分隔样式） */
function descNodes(tpl: string, vars: Record<string, string | number>) {
  const colors: Record<string, string> = { total: '#00ff9c', comps: '#22d3ee', cves: '#fbbf24' };
  return tpl.split(/(\{\w+\})/g).map((p, i) => {
    const m = /^\{(\w+)\}$/.exec(p);
    if (m) {
      const k = m[1];
      return (
        <span key={i} className="font-mono" style={{ color: colors[k] ?? '#e6edf3' }}>
          {vars[k]}
        </span>
      );
    }
    return <span key={i}>{p}</span>;
  });
}

/* ---------- 终端打字动画 ---------- */
interface TerminalHeroProps {
  lines: TerminalLine[];
  total: number;
  compCount: number;
  yearMin: number;
  yearMax: number;
}

function TerminalHero({ lines, total, compCount, yearMin, yearMax }: TerminalHeroProps) {
  const t = useT();
  const [lineIdx, setLineIdx] = useState(0);
  const [charIdx, setCharIdx] = useState(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (lineIdx >= lines.length) return;
    const line = lines[lineIdx].text;
    if (charIdx < line.length) {
      timer.current = setTimeout(() => setCharIdx((c) => c + 1), 22);
    } else {
      timer.current = setTimeout(() => {
        setLineIdx((l) => l + 1);
        setCharIdx(0);
      }, 260);
    }
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [lineIdx, charIdx, lines.length]);

  const done = lineIdx >= lines.length;

  return (
    <div className="scanlines relative overflow-hidden rounded-2xl border border-[#21262d] bg-[#0a0d12]/90 p-5 sm:p-8 glow-border">
      {/* 顶栏 */}
      <div className="mb-5 flex items-center gap-2">
        <span className="h-3 w-3 rounded-full bg-[#ff5f57]" />
        <span className="h-3 w-3 rounded-full bg-[#febc2e]" />
        <span className="h-3 w-3 rounded-full bg-[#28c840]" />
        <span className="ml-3 font-mono text-[11px] text-[#8b949e]">root@vulhub: ~/notes</span>
      </div>

      <div className="min-h-[9.5rem] font-mono text-[12.5px] sm:text-sm leading-7">
        {lines.slice(0, lineIdx + 1).map((l, i) => {
          const isCurrent = i === lineIdx;
          const text = isCurrent ? l.text.slice(0, charIdx) : l.text;
          return (
            <div key={i} className="fade-up" style={isCurrent ? undefined : { animationDelay: `${i * 0.05}s` }}>
              {l.prompt ? (
                <span>
                  <span className="text-[#00ff9c]">➜</span> <span className="text-[#22d3ee]">~</span>{' '}
                  <span className="text-[#e6edf3]">{text}</span>
                </span>
              ) : (
                <span className={text.startsWith('[✓]') ? 'text-[#7ee8b6]' : 'text-[#8b949e]'}>{text}</span>
              )}
              {isCurrent && <span className="cursor-blink ml-0.5 inline-block h-[1.1em] w-[7px] translate-y-[3px] bg-[#00ff9c]" />}
            </div>
          );
        })}
        {done && (
          <span className="cursor-blink ml-0.5 inline-block h-[1.1em] w-[7px] translate-y-[3px] bg-[#00ff9c]" />
        )}
      </div>

      <div className="mt-5 flex flex-wrap gap-2">
        {[
          fmt(t.badgeNotes, { n: total }),
          fmt(t.badgeComps, { n: compCount }),
          `${yearMin} - ${yearMax}`,
          t.badgeIllustrated,
        ].map((b) => (
          <span
            key={b}
            className="rounded-full border border-[#00ff9c]/25 bg-[#00ff9c]/5 px-3 py-1 font-mono text-[11px] text-[#7ee8b6]"
          >
            {b}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ---------- 主视图 ---------- */
const COMP_PREVIEW_COUNT = 42;

export function HomeView() {
  const data = useAppStore((s) => s.data);
  const read = useAppStore((s) => s.read);
  const fav = useAppStore((s) => s.fav);
  const lang = useAppStore((s) => s.lang);
  const t = useT();
  const [showAllComps, setShowAllComps] = useState(false);

  const goLibrary = (patch: { type?: string; comp?: string }) => {
    navigate({
      name: 'library',
      query: {
        q: '',
        type: patch.type ?? '',
        comp: patch.comp ?? '',
        status: '',
      },
    });
  };

  const stats = useMemo(() => {
    if (!data) return null;
    const cveCount = new Set<string>();
    data.vulns.forEach((v) => v.cves.forEach((c) => cveCount.add(c)));
    return {
      total: data.total,
      components: data.components.length,
      cves: cveCount.size,
      readPct: Math.round((read.length / data.total) * 100),
    };
  }, [data, read.length]);

  const maxTypeCount = useMemo(() => {
    if (!data) return 1;
    return Math.max(
      1,
      ...data.types.map((t) => data.vulns.filter((v) => v.type === t).length)
    );
  }, [data]);

  const featured = useMemo(() => data?.vulns.filter((v) => v.featured) ?? [], [data]);
  const years = useMemo(() => {
    if (!data) return [] as [number, number][];
    const m = new Map<number, number>();
    data.vulns.forEach((v) => {
      if (v.year) m.set(v.year, (m.get(v.year) ?? 0) + 1);
    });
    return [...m.entries()].sort((a, b) => a[0] - b[0]);
  }, [data]);
  const maxYear = Math.max(1, ...years.map((y) => y[1]));

  const yearMin = years.length > 0 ? years[0][0] : 2010;
  const yearMax = years.length > 0 ? years[years.length - 1][0] : 2024;
  const noCveCount = useMemo(() => data?.vulns.filter((v) => !v.year).length ?? 0, [data]);

  const terminalLines = useMemo(
    () =>
      data && stats
        ? buildTerminalLines(data.total, data.components.length, yearMin, yearMax, stats.cves, lang)
        : [],
    [data, stats, yearMin, yearMax, lang]
  );

  const visibleComps = useMemo(
    () => (showAllComps ? (data?.components ?? []) : (data?.components ?? []).slice(0, COMP_PREVIEW_COUNT)),
    [data, showAllComps]
  );

  if (!data || !stats) return null;

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8 sm:py-12">
      {/* Hero */}
      <div className="grid gap-8 lg:grid-cols-[1.2fr_1fr] lg:items-center mb-10">
        <div>
          <p className="mb-3 font-mono text-[12px] tracking-[0.3em] text-[#00ff9c]">
            {'// VULHUB PENTEST RANGE · WALKTHROUGH NOTES'}
          </p>
          <h1 className="text-3xl sm:text-4xl lg:text-[2.75rem] font-bold leading-tight text-[#f0f6fc]">
            {t.heroTitle1}
            <br />
            <span className="neon-text font-mono">{t.heroTitle2a}</span>
            {t.heroTitle2b}
          </h1>
          <p className="mt-4 max-w-xl text-[14.5px] leading-relaxed text-[#8b949e]">
            {stats &&
              descNodes(t.heroDesc, {
                total: stats.total,
                comps: stats.components,
                cves: stats.cves,
              })}
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => goLibrary({})}
              className="inline-flex items-center gap-2 rounded-lg bg-[#00ff9c] px-5 py-2.5 text-[14px] font-semibold text-[#052e16] transition-all hover:shadow-[0_0_28px_rgba(0,255,156,0.45)]"
            >
              {t.ctaLibrary}
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => navigate({ name: 'guide' })}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#00ff9c]/45 bg-[#00ff9c]/5 px-5 py-2.5 text-[14px] font-medium text-[#00ff9c] transition-colors hover:bg-[#00ff9c]/12"
            >
              <BookOpen className="h-4 w-4" />
              {t.ctaGuide}
            </button>
            <button
              type="button"
              onClick={() => {
                document.getElementById('featured')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#30363d] bg-[#161b22] px-5 py-2.5 text-[14px] text-[#c9d4de] transition-colors hover:border-[#00ff9c]/50 hover:text-[#00ff9c]"
            >
              <Star className="h-4 w-4 text-[#fbbf24]" />
              {t.ctaFeatured}
            </button>
          </div>
        </div>
        <TerminalHero
          lines={terminalLines}
          total={stats.total}
          compCount={stats.components}
          yearMin={yearMin}
          yearMax={yearMax}
        />
      </div>

      {/* 统计看板 */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
        {[
          { icon: FileText, label: t.statsNotes, value: stats.total, suffix: t.statsNotesUnit, color: '#00ff9c' },
          { icon: Fingerprint, label: t.statsCves, value: stats.cves, suffix: t.statsCvesUnit, color: '#22d3ee' },
          { icon: Layers, label: t.statsComps, value: stats.components, suffix: t.statsCompsUnit, color: '#fbbf24' },
          { icon: Cpu, label: t.statsProgress, value: read.length, suffix: fmt(t.statsProgressSuffix, { n: stats.total }), color: '#c084fc' },
        ].map((s) => (
          <div key={s.label} className="rounded-xl border border-[#21262d] bg-[#161b22] p-4 sm:p-5">
            <div className="mb-2 flex items-center gap-2">
              <s.icon className="h-4 w-4" style={{ color: s.color }} />
              <span className="text-[12px] text-[#8b949e]">{s.label}</span>
            </div>
            <p className="font-mono text-2xl sm:text-3xl font-bold" style={{ color: s.color }}>
              {s.value}
              <span className="ml-1 text-[12px] font-normal text-[#8b949e]">{s.suffix}</span>
            </p>
            {s.label === '刷洞进度' && (
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#21262d]">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#c084fc] to-[#00ff9c] transition-all duration-500"
                  style={{ width: `${stats.readPct}%` }}
                />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* 新人必读 Banner */}
      <section className="mb-10 overflow-hidden rounded-xl border border-[#00ff9c]/25 bg-gradient-to-r from-[#00ff9c]/8 via-[#161b22] to-[#161b22] p-5 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <h2 className="flex items-center gap-2 text-[15.5px] font-bold text-[#f0f6fc]">
              <BookOpen className="h-4.5 w-4.5 shrink-0 text-[#00ff9c]" />
              {t.bannerTitle}
            </h2>
            <p className="mt-1.5 max-w-2xl text-[13px] leading-relaxed text-[#8b949e]">{t.bannerText}</p>
            <div className="mt-2.5 flex flex-wrap gap-1.5">
              {t.bannerTags.map((tag) => (
                <span
                  key={tag}
                  className="rounded border border-[#00ff9c]/20 bg-[#00ff9c]/5 px-2 py-0.5 font-mono text-[10.5px] text-[#7ee8b6]"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
          <button
            type="button"
            onClick={() => navigate({ name: 'guide' })}
            className="inline-flex shrink-0 items-center gap-2 self-start rounded-lg bg-[#00ff9c] px-5 py-2.5 text-[13.5px] font-semibold text-[#052e16] transition-all hover:shadow-[0_0_28px_rgba(0,255,156,0.45)] sm:self-auto"
          >
            {t.bannerCta}
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </section>

      {/* 类型分布 + 年份直方图 */}
      <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr] mb-12">
        <section className="rounded-xl border border-[#21262d] bg-[#161b22] p-5">
          <h2 className="mb-4 font-mono text-[13px] tracking-widest text-[#8b949e]">
            {t.typeDistTitle}<span className="text-[#00ff9c]">·</span>{t.typeDistHint}
          </h2>
          <div className="flex flex-col gap-2.5">
            {data.types.map((ty) => {
              const count = data.vulns.filter((v) => v.type === ty).length;
              const c = typeColor(ty);
              return (
                <button
                  key={ty}
                  type="button"
                  onClick={() => goLibrary({ type: ty })}
                  className="group flex items-center gap-3 text-left"
                >
                  <span
                    className="w-[104px] shrink-0 truncate text-[12px]"
                    style={{ color: c.fg }}
                  >
                    {typeName(ty, lang)}
                  </span>
                  <span className="relative h-5 flex-1 overflow-hidden rounded bg-[#0d1117]">
                    <span
                      className="absolute inset-y-0 left-0 rounded transition-all duration-500 group-hover:brightness-125"
                      style={{
                        width: `${(count / maxTypeCount) * 100}%`,
                        background: `linear-gradient(90deg, ${c.fg}55, ${c.fg}22)`,
                        borderLeft: `2px solid ${c.fg}`,
                      }}
                    />
                  </span>
                  <span className="w-8 shrink-0 text-right font-mono text-[12px] text-[#c9d4de]">{count}</span>
                </button>
              );
            })}
          </div>
        </section>

        <section className="rounded-xl border border-[#21262d] bg-[#161b22] p-5">
          <h2 className="mb-4 font-mono text-[13px] tracking-widest text-[#8b949e]">
            {t.yearDistTitle}<span className="text-[#00ff9c]">·</span>{` ${yearMin} - ${yearMax}`}
          </h2>
          <div className="flex h-[180px] items-end gap-[6px]">
            {years.map(([y, n]) => (
              <button
                key={y}
                type="button"
                onClick={() => navigate({
                  name: 'library',
                  query: { q: String(y), type: '', comp: '', status: '' },
                })}
                className="group relative flex h-full flex-1 flex-col justify-end items-center gap-1.5"
                title={`${y} 年：${n} 篇`}
              >
                <span className="font-mono text-[10px] text-[#8b949e] group-hover:text-[#00ff9c]">{n}</span>
                <span
                  className="w-full rounded-t bg-gradient-to-t from-[#00ff9c]/25 to-[#00ff9c]/70 transition-all duration-300 group-hover:from-[#00ff9c]/45 group-hover:to-[#00ff9c]"
                  style={{ height: `${Math.max(8, (n / maxYear) * 128)}px` }}
                />
                <span className="font-mono text-[9px] text-[#6e7681]">{String(y).slice(2)}</span>
              </button>
            ))}
          </div>
          <p className="mt-3 text-center font-mono text-[10.5px] text-[#6e7681]">
            {fmt(t.yearHint, { n: noCveCount })}
          </p>
        </section>
      </div>

      {/* 精选经典 */}
      <section id="featured" className="mb-12 scroll-mt-20">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-lg font-bold text-[#f0f6fc]">
            <Star className="h-4.5 w-4.5 fill-[#fbbf24] text-[#fbbf24]" />
            {t.featuredTitle}
            <span className="font-mono text-[12px] font-normal text-[#8b949e]">{t.featuredSub}</span>
          </h2>
          <button
            type="button"
            onClick={() => goLibrary({})}
            className="inline-flex items-center gap-1 text-[13px] text-[#22d3ee] hover:text-[#00ff9c]"
          >
            {t.viewAll} <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
        <div className="grid gap-3 sm:gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {featured.map((v) => (
            <VulnCard key={v.id} vuln={v} />
          ))}
        </div>
      </section>

      {/* 组件导航 */}
      <section>
        <h2 className="mb-5 flex items-center gap-2 text-lg font-bold text-[#f0f6fc]">
          <Layers className="h-4.5 w-4.5 text-[#22d3ee]" />
          {t.compTitle}
          <span className="font-mono text-[12px] font-normal text-[#8b949e]">{fmt(t.compCount, { n: data.components.length })}</span>
        </h2>
        <div className="flex flex-wrap gap-2">
          {visibleComps.map(([comp, count]) => (
            <button
              key={comp}
              type="button"
              onClick={() => goLibrary({ comp })}
              className="group inline-flex items-center gap-2 rounded-lg border border-[#21262d] bg-[#161b22] px-3.5 py-2 transition-all hover:border-[#00ff9c]/50 hover:bg-[#00ff9c]/5"
            >
              <span className="font-mono text-[10px] text-[#6e7681] group-hover:text-[#00ff9c]">
                {String(count).padStart(2, '0')}
              </span>
              <span className="text-[13px] text-[#c9d4de] group-hover:text-[#e6edf3]">{comp}</span>
            </button>
          ))}
          {data.components.length > COMP_PREVIEW_COUNT && (
            <button
              type="button"
              onClick={() => setShowAllComps((v) => !v)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-dashed border-[#00ff9c]/40 bg-transparent px-3.5 py-2 font-mono text-[12px] text-[#00ff9c] transition-colors hover:bg-[#00ff9c]/5"
            >
              {showAllComps ? t.collapseComps : fmt(t.expandAll, { n: data.components.length })}
              <ChevronDown className={`h-3.5 w-3.5 transition-transform ${showAllComps ? 'rotate-180' : ''}`} />
            </button>
          )}
        </div>
      </section>

      {/* 收藏提示 */}
      {fav.length > 0 && (
        <p className="mt-8 text-center font-mono text-[11.5px] text-[#8b949e]">
          {fmt(t.favHint, { n: fav.length })}
        </p>
      )}
    </div>
  );
}
