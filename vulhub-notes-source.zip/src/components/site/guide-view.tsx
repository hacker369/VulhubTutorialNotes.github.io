'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Clock, Globe } from 'lucide-react';
import { navigate, useAppStore } from '@/lib/store';
import { useT, fmt } from '@/lib/i18n';
import { GUIDE_ZH, GUIDE_EN } from '@/lib/guide-content';
import MarkdownRender from '@/components/site/markdown';

interface TocItem {
  id: string;
  text: string;
  level: number;
}

export function GuideView() {
  const t = useT();
  const lang = useAppStore((s) => s.lang);
  const setLang = useAppStore((s) => s.setLang);
  const contentRef = useRef<HTMLDivElement>(null);
  const [toc, setToc] = useState<TocItem[]>([]);
  const [activeId, setActiveId] = useState('');

  const content = lang === 'zh' ? GUIDE_ZH : GUIDE_EN;

  /* 进入页面：回顶部 + 提取目录 */
  useEffect(() => {
    window.scrollTo({ top: 0 });
    const timer = setTimeout(() => {
      const hs = contentRef.current?.querySelectorAll<HTMLElement>('h2[id], h3[id]');
      if (hs) {
        const items: TocItem[] = [];
        hs.forEach((h) => {
          items.push({
            id: h.id,
            text: h.textContent ?? '',
            level: h.tagName === 'H2' ? 2 : 3,
          });
        });
        setToc(items);
      }
    }, 120);
    return () => clearTimeout(timer);
  }, [content]);

  /* 目录高亮追踪 */
  const onScroll = useCallback(() => {
    const hs = contentRef.current?.querySelectorAll<HTMLElement>('h2[id], h3[id]');
    if (!hs || hs.length === 0) return;
    let current = '';
    hs.forEach((h) => {
      if (h.getBoundingClientRect().top <= 120) current = h.id;
    });
    setActiveId(current || hs[0].id);
  }, []);

  useEffect(() => {
    window.addEventListener('scroll', onScroll, { passive: true });
    const raf = requestAnimationFrame(onScroll);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('scroll', onScroll);
    };
  }, [onScroll]);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
      {/* 页头 */}
      <header className="mb-6 rounded-2xl border border-[#21262d] bg-[#161b22] p-5 sm:p-7 glow-border">
        <p className="mb-2 font-mono text-[12px] tracking-[0.3em] text-[#00ff9c]">{t.guideEyebrow}</p>
        <h1 className="text-2xl sm:text-3xl font-bold text-[#f0f6fc]">{t.guideTitle}</h1>
        <p className="mt-3 max-w-3xl text-[14px] leading-relaxed text-[#8b949e]">{t.guideSub}</p>

        <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 font-mono text-[11.5px] text-[#8b949e]">
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3.5 w-3.5 text-[#fbbf24]/70" /> {fmt(t.guideMeta, { n: 12 })}
          </span>
          {/* 指南语言切换（独立于站点 UI 语言，方便英文用户读英文指南） */}
          <span className="inline-flex items-center gap-1.5">
            <Globe className="h-3.5 w-3.5 text-[#22d3ee]/70" />
            <span className="flex overflow-hidden rounded-md border border-[#30363d]">
              <button
                type="button"
                onClick={() => setLang('zh')}
                className={`px-2.5 py-1 text-[11px] transition-colors ${
                  lang === 'zh' ? 'bg-[#00ff9c]/12 text-[#00ff9c]' : 'text-[#8b949e] hover:text-[#c9d4de]'
                }`}
              >
                中文
              </button>
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`px-2.5 py-1 text-[11px] transition-colors ${
                  lang === 'en' ? 'bg-[#00ff9c]/12 text-[#00ff9c]' : 'text-[#8b949e] hover:text-[#c9d4de]'
                }`}
              >
                English
              </button>
            </span>
          </span>
        </div>
      </header>

      <div className="grid gap-8 xl:grid-cols-[1fr_230px]">
        {/* 正文 */}
        <div ref={contentRef} className="min-w-0 rounded-2xl border border-[#21262d] bg-[#161b22] p-5 sm:p-7">
          <MarkdownRender content={content} />

          {/* 底部 CTA */}
          <div className="mt-8 flex flex-wrap items-center gap-3 border-t border-[#21262d] pt-6">
            <button
              type="button"
              onClick={() => navigate({ name: 'library', query: { q: '', type: '', comp: '', status: '' } })}
              className="inline-flex items-center gap-2 rounded-lg bg-[#00ff9c] px-5 py-2.5 text-[14px] font-semibold text-[#052e16] transition-all hover:shadow-[0_0_28px_rgba(0,255,156,0.45)]"
            >
              {t.guideCta}
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => navigate({ name: 'home' })}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#30363d] bg-[#161b22] px-5 py-2.5 text-[14px] text-[#c9d4de] transition-colors hover:border-[#00ff9c]/50 hover:text-[#00ff9c]"
            >
              <ArrowLeft className="h-4 w-4" />
              {t.navHome}
            </button>
          </div>
        </div>

        {/* 目录侧栏 */}
        <aside className="hidden xl:block">
          <div className="sticky top-20 max-h-[calc(100vh-6rem)] overflow-y-auto pr-1">
            <h2 className="mb-3 flex items-center gap-1.5 font-mono text-[11.5px] tracking-widest text-[#8b949e]">
              <ArrowRight className="h-3 w-3 text-[#00ff9c]" /> {t.tocTitle}
            </h2>
            {toc.length > 0 ? (
              <nav className="flex flex-col" aria-label="guide toc">
                {toc.map((item) => (
                  <a
                    key={item.id}
                    href={`#${item.id}`}
                    onClick={(e) => {
                      e.preventDefault();
                      document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className={`toc-link ${activeId === item.id ? 'active' : ''} ${item.level === 3 ? 'pl-[1.7em]' : ''}`}
                    title={item.text}
                  >
                    <span className="line-clamp-1">{item.text}</span>
                  </a>
                ))}
              </nav>
            ) : (
              <p className="font-mono text-[11px] text-[#6e7681]">{t.tocLoading}</p>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
