'use client';

import { useState } from 'react';
import { BookOpen, Github, Globe, Home, Library, Menu, ShieldCheck, X } from 'lucide-react';
import { navigate, useAppStore } from '@/lib/store';
import { useT } from '@/lib/i18n';

const REPO_URL = 'https://github.com/hacker369/VulhubTutorialNotes.github.io';

export function Navbar() {
  const route = useAppStore((s) => s.route);
  const data = useAppStore((s) => s.data);
  const read = useAppStore((s) => s.read);
  const lang = useAppStore((s) => s.lang);
  const setLang = useAppStore((s) => s.setLang);
  const t = useT();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isHome = route.name === 'home';
  const isGuide = route.name === 'guide';
  const total = data?.total ?? 0;
  const pct = total > 0 ? Math.round((read.length / total) * 100) : 0;

  const go = (r: Parameters<typeof navigate>[0]) => {
    setMobileOpen(false);
    navigate(r);
  };

  const navItemCls = (active: boolean) =>
    `inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[13px] transition-colors ${
      active ? 'bg-[#00ff9c]/10 text-[#00ff9c]' : 'text-[#8b949e] hover:text-[#e6edf3] hover:bg-[#1c2128]'
    }`;

  return (
    <header className="sticky top-0 z-50 border-b border-[#21262d] bg-[#0d1117]/85 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-3 px-4 sm:px-6">
        {/* Logo */}
        <button
          type="button"
          onClick={() => go({ name: 'home' })}
          className="flex items-center gap-2.5 group"
          aria-label="回到首页"
        >
          <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-[#00ff9c]/40 bg-[#00ff9c]/10 glow-border">
            <ShieldCheck className="h-4.5 w-4.5 text-[#00ff9c]" />
          </span>
          <span className="hidden sm:flex flex-col items-start leading-none">
            <span className="font-mono text-[15px] font-bold tracking-wide text-[#e6edf3] group-hover:text-[#00ff9c] transition-colors">
              VULHUB<span className="text-[#00ff9c]">_</span>
              {lang === 'zh' ? '漏洞复现' : 'NOTES'}
            </span>
            <span className="mt-1 font-mono text-[9.5px] tracking-[0.22em] text-[#8b949e]">
              PENTEST RANGE WALKTHROUGH
            </span>
          </span>
        </button>

        {/* 桌面导航 */}
        <nav className="hidden md:flex items-center gap-1" aria-label="主导航">
          <button type="button" onClick={() => go({ name: 'home' })} className={navItemCls(isHome)}>
            <Home className="h-3.5 w-3.5" />
            {t.navHome}
          </button>
          <button
            type="button"
            onClick={() => go({ name: 'library', query: { q: '', type: '', comp: '', status: '' } })}
            className={navItemCls(route.name === 'library' || route.name === 'vuln')}
          >
            <Library className="h-3.5 w-3.5" />
            {t.navLibrary}
          </button>
          <button type="button" onClick={() => go({ name: 'guide' })} className={navItemCls(isGuide)}>
            <BookOpen className="h-3.5 w-3.5" />
            {t.navGuide}
          </button>
          <a
            href={REPO_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[13px] text-[#8b949e] transition-colors hover:text-[#e6edf3] hover:bg-[#1c2128]"
          >
            <Github className="h-3.5 w-3.5" />
            GitHub
          </a>
        </nav>

        {/* 语言切换 + 阅读进度 + 移动端菜单按钮 */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setLang(lang === 'zh' ? 'en' : 'zh')}
            className="inline-flex items-center gap-1 rounded-full border border-[#30363d] bg-[#161b22] px-2.5 py-1 font-mono text-[11px] text-[#8b949e] transition-colors hover:border-[#00ff9c]/50 hover:text-[#00ff9c]"
            aria-label={lang === 'zh' ? 'Switch to English' : '切换到中文'}
            title={lang === 'zh' ? 'Switch to English' : '切换到中文'}
          >
            <Globe className="h-3 w-3" />
            {t.switchLang}
          </button>

          {total > 0 && (
            <div
              className="hidden sm:flex items-center gap-2 rounded-full border border-[#21262d] bg-[#161b22] px-3 py-1"
              title={`已读 ${read.length}/${total}`}
            >
              <span className="font-mono text-[10.5px] text-[#8b949e]">
                {t.progress} {read.length}/{total}
              </span>
              <div className="h-1.5 w-16 overflow-hidden rounded-full bg-[#21262d]">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#00ff9c] to-[#22d3ee] transition-all duration-500"
                  style={{ width: `${pct}%` }}
                />
              </div>
              <span className="font-mono text-[10.5px] text-[#00ff9c]">{pct}%</span>
            </div>
          )}
          <button
            type="button"
            className="md:hidden rounded-md p-2 text-[#8b949e] hover:bg-[#1c2128] hover:text-[#e6edf3]"
            onClick={() => setMobileOpen((v) => !v)}
            aria-label="菜单"
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* 移动端菜单 */}
      {mobileOpen && (
        <nav className="md:hidden border-t border-[#21262d] bg-[#0d1117] px-4 py-3 flex flex-col gap-1" aria-label="移动端导航">
          <button
            type="button"
            onClick={() => go({ name: 'home' })}
            className={`inline-flex items-center gap-2 rounded-md px-3 py-2.5 text-sm ${
              isHome ? 'bg-[#00ff9c]/10 text-[#00ff9c]' : 'text-[#c9d4de] hover:bg-[#1c2128]'
            }`}
          >
            <Home className="h-4 w-4" /> {t.navHome}
          </button>
          <button
            type="button"
            onClick={() => go({ name: 'library', query: { q: '', type: '', comp: '', status: '' } })}
            className="inline-flex items-center gap-2 rounded-md px-3 py-2.5 text-sm text-[#c9d4de] hover:bg-[#1c2128]"
          >
            <Library className="h-4 w-4" /> {t.navLibrary}
          </button>
          <button
            type="button"
            onClick={() => go({ name: 'guide' })}
            className={`inline-flex items-center gap-2 rounded-md px-3 py-2.5 text-sm ${
              isGuide ? 'bg-[#00ff9c]/10 text-[#00ff9c]' : 'text-[#c9d4de] hover:bg-[#1c2128]'
            }`}
          >
            <BookOpen className="h-4 w-4" /> {t.navGuide}
          </button>
          <a
            href={REPO_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-md px-3 py-2.5 text-sm text-[#c9d4de] hover:bg-[#1c2128]"
          >
            <Github className="h-4 w-4" /> GitHub
          </a>
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  const t = useT();
  return (
    <footer className="mt-auto border-t border-[#21262d] bg-[#0d1117]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-6 pb-[max(1.5rem,env(safe-area-inset-bottom))]">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-mono text-[11.5px] text-[#8b949e]">
            <span className="text-[#00ff9c]">$</span> {t.footerBuiltPre}
            <a
              href="https://github.com/hacker369/VulhubTutorialNotes.github.io"
              target="_blank"
              rel="noopener noreferrer"
              className="mx-1 text-[#22d3ee] hover:text-[#00ff9c] underline decoration-dotted underline-offset-2"
            >
              VulhubTutorialNotes
            </a>
            {t.footerBuiltPost}
          </p>
          <p className="font-mono text-[11px] text-[#6e7681]">{t.footerLegal}</p>
        </div>
      </div>
    </footer>
  );
}
