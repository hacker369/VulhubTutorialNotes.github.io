'use client';

import { memo } from 'react';
import { CheckCircle2, Code2, ImageIcon, Star, Terminal } from 'lucide-react';
import type { Vuln } from '@/lib/types';
import { typeColor } from '@/lib/types';
import { useAppStore } from '@/lib/store';
import { useT, typeName } from '@/lib/i18n';
import { navigate } from '@/lib/store';

interface Props {
  vuln: Vuln;
  showFav?: boolean;
}

function VulnCardBase({ vuln, showFav = true }: Props) {
  const read = useAppStore((s) => s.read.includes(vuln.id));
  const fav = useAppStore((s) => s.fav.includes(vuln.id));
  const toggleFav = useAppStore((s) => s.toggleFav);
  const lang = useAppStore((s) => s.lang);
  const t = useT();
  const c = typeColor(vuln.type);

  const open = () => navigate({ name: 'vuln', id: vuln.id });

  return (
    <div
      className="vuln-card group relative flex flex-col rounded-xl border border-[#21262d] bg-[#161b22] p-4 cursor-pointer select-none"
      onClick={open}
      role="link"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter') open();
      }}
      aria-label={`打开漏洞笔记：${vuln.title}`}
    >
      {/* 顶部：组件 + 已读/精选 */}
      <div className="mb-2.5 flex items-center justify-between gap-2">
        <span className="inline-flex items-center gap-1.5 font-mono text-[11px] text-[#8b949e] truncate">
          <Terminal className="h-3 w-3 shrink-0 text-[#00ff9c]/70" />
          <span className="truncate">{vuln.component}</span>
        </span>
        <div className="flex items-center gap-1.5 shrink-0">
          {vuln.featured && (
            <span className="rounded border border-[#fbbf24]/40 bg-[#fbbf24]/10 px-1.5 py-0.5 font-mono text-[10px] text-[#fbbf24]">
              {t.classicBadge}
            </span>
          )}
          {read && <CheckCircle2 className="h-3.5 w-3.5 text-[#00ff9c]" aria-label="已读" />}
        </div>
      </div>

      {/* 标题 */}
      <h3 className="mb-3 line-clamp-2 min-h-[2.6em] text-[0.92rem] font-semibold leading-[1.45] text-[#e6edf3] group-hover:text-[#00ff9c] transition-colors">
        {vuln.title}
      </h3>

      {/* CVE 徽章 */}
      <div className="mb-3 flex flex-wrap gap-1.5 min-h-[1.6em]">
        {vuln.cves.length > 0 ? (
          vuln.cves.slice(0, 2).map((cve) => (
            <span
              key={cve}
              className="rounded border border-[#00ff9c]/30 bg-[#00ff9c]/5 px-1.5 py-0.5 font-mono text-[10.5px] text-[#7ee8b6]"
            >
              {cve}
            </span>
          ))
        ) : (
          <span className="rounded border border-[#30363d] px-1.5 py-0.5 font-mono text-[10.5px] text-[#8b949e]">
            {t.noCve}
          </span>
        )}
        {vuln.cves.length > 2 && (
          <span className="font-mono text-[10.5px] text-[#8b949e] self-center">+{vuln.cves.length - 2}</span>
        )}
      </div>

      {/* 底部：类型 + 统计 + 收藏 */}
      <div className="mt-auto flex items-center justify-between gap-2 border-t border-[#21262d] pt-2.5">
        <span
          className="rounded px-1.5 py-0.5 text-[11px] font-medium border"
          style={{ color: c.fg, backgroundColor: c.bg, borderColor: c.border }}
        >
          {typeName(vuln.type, lang)}
        </span>
        <div className="flex items-center gap-2.5 text-[#8b949e]">
          <span className="inline-flex items-center gap-1 font-mono text-[10.5px]" title="代码块">
            <Code2 className="h-3 w-3" />
            {vuln.codeBlocks}
          </span>
          <span className="inline-flex items-center gap-1 font-mono text-[10.5px]" title="截图">
            <ImageIcon className="h-3 w-3" />
            {vuln.images}
          </span>
          {showFav && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                toggleFav(vuln.id);
              }}
              aria-label={fav ? '取消收藏' : '收藏'}
              className="transition-transform hover:scale-110"
            >
              <Star
                className={`h-3.5 w-3.5 ${fav ? 'fill-[#fbbf24] text-[#fbbf24]' : 'text-[#8b949e] hover:text-[#fbbf24]'}`}
              />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export const VulnCard = memo(VulnCardBase);
