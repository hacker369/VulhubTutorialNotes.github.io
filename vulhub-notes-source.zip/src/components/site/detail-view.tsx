'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft, ArrowRight, Calendar, CheckCircle2, ChevronLeft, ChevronRight,
  Clock, Globe, ImageIcon, Code2, Star,
} from 'lucide-react';
import { navigate, useAppStore } from '@/lib/store';
import { typeColor } from '@/lib/types';
import { useT, fmt, typeName } from '@/lib/i18n';
import MarkdownRender, { CopyLinkButton } from '@/components/site/markdown';

interface TocItem {
  id: string;
  text: string;
  level: number;
}

interface Props {
  id: string;
}

export function DetailView({ id }: Props) {
  const data = useAppStore((s) => s.data);
  const read = useAppStore((s) => s.read);
  const fav = useAppStore((s) => s.fav);
  const lang = useAppStore((s) => s.lang);
  const t = useT();
  const toggleRead = useAppStore((s) => s.toggleRead);
  const toggleFav = useAppStore((s) => s.toggleFav);
  const markRead = useAppStore((s) => s.markRead);
  const lightbox = useAppStore((s) => s.lightbox);
  const setLightbox = useAppStore((s) => s.setLightbox);

  const contentRef = useRef<HTMLDivElement>(null);
  const [toc, setToc] = useState<TocItem[]>([]);
  const [activeId, setActiveId] = useState('');

  const vuln = useMemo(() => data?.vulns.find((v) => v.id === id), [data, id]);
  const index = useMemo(() => (vuln && data ? data.vulns.indexOf(vuln) : -1), [vuln, data]);
  const prev = index > 0 ? data?.vulns[index - 1] : undefined;
  const next = data && index >= 0 && index < data.vulns.length - 1 ? data.vulns[index + 1] : undefined;
  const related = useMemo(
    () =>
      vuln && data
        ? data.vulns.filter((v) => v.id !== vuln.id && v.component === vuln.component).slice(0, 6)
        : [],
    [vuln, data]
  );

  const isRead = vuln ? read.includes(vuln.id) : false;
  const isFav = vuln ? fav.includes(vuln.id) : false;

  /* 进入详情：滚动到顶部 + 提取目录 + 自动标记已读 */
  useEffect(() => {
    window.scrollTo({ top: 0 });
    if (vuln) markRead(vuln.id);
    const t = setTimeout(() => {
      const hs = contentRef.current?.querySelectorAll<HTMLElement>('h2[id], h3[id]');
      if (hs) {
        const items: TocItem[] = [];
        hs.forEach((h) => {
          items.push({
            id: h.id,
            text: h.textContent ?? '',
            level: h.tagName === 'H2' ? 2 : 3,
          });
        });
        setToc(items);
      }
    }, 120);
    return () => clearTimeout(t);
  }, [vuln, markRead]);

  /* 目录高亮追踪 */
  const onScroll = useCallback(() => {
    const hs = contentRef.current?.querySelectorAll<HTMLElement>('h2[id], h3[id]');
    if (!hs || hs.length === 0) return;
    let current = '';
    hs.forEach((h) => {
      if (h.getBoundingClientRect().top <= 120) current = h.id;
    });
    setActiveId(current || hs[0].id);
  }, []);

  useEffect(() => {
    window.addEventListener('scroll', onScroll, { passive: true });
    const raf = requestAnimationFrame(onScroll);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('scroll', onScroll);
    };
  }, [onScroll, id]);

  /* 灯箱 ESC 关闭 */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setLightbox(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [setLightbox]);

  if (!data) return null;
  if (!vuln) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="font-mono text-[14px] text-[#8b949e]">
          <span className="text-[#f87171]">404</span> · {fmt(t.notFoundId, { id })}
        </p>
        <button
          type="button"
          onClick={() => navigate({ name: 'library', query: { q: '', type: '', comp: '', status: '' } })}
          className="mt-6 inline-flex items-center gap-2 rounded-lg border border-[#00ff9c]/40 bg-[#00ff9c]/5 px-4 py-2 text-[13px] text-[#00ff9c]"
        >
          <ArrowLeft className="h-4 w-4" /> {t.backLibrary}
        </button>
      </div>
    );
  }

  const c = typeColor(vuln.type);
  const words = vuln.content.length;

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-6 sm:py-8">
      {/* 面包屑 */}
      <nav className="mb-5 flex items-center gap-1.5 font-mono text-[12px] text-[#8b949e]" aria-label="面包屑">
        <button
          type="button"
          onClick={() => navigate({ name: 'home' })}
          className="hover:text-[#00ff9c]"
        >
          ~
        </button>
        <span className="text-[#484f58]">/</span>
        <button
          type="button"
          onClick={() => navigate({ name: 'library', query: { q: '', type: '', comp: vuln.component, status: '' } })}
          className="hover:text-[#00ff9c]"
        >
          {vuln.component}
        </button>
        <span className="text-[#484f58]">/</span>
        <span className="text-[#c9d4de] truncate max-w-[280px] sm:max-w-none">#{vuln.no} {vuln.title}</span>
      </nav>

      <div className="grid gap-8 xl:grid-cols-[1fr_230px]">
        {/* 正文列 */}
        <article className="min-w-0">
          {/* 标题区 */}
          <header className="mb-6 rounded-2xl border border-[#21262d] bg-[#161b22] p-5 sm:p-6">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <span
                className="rounded px-2 py-0.5 text-[11.5px] font-medium border"
                style={{ color: c.fg, backgroundColor: c.bg, borderColor: c.border }}
              >
                {typeName(vuln.type, lang)}
              </span>
              {vuln.cves.map((cve) => (
                <span
                  key={cve}
                  className="rounded border border-[#00ff9c]/30 bg-[#00ff9c]/5 px-2 py-0.5 font-mono text-[11.5px] text-[#7ee8b6]"
                >
                  {cve}
                </span>
              ))}
              {vuln.featured && (
                <span className="rounded border border-[#fbbf24]/40 bg-[#fbbf24]/10 px-2 py-0.5 font-mono text-[11.5px] text-[#fbbf24]">
                  ★ {t.classicBadge}
                </span>
              )}
            </div>

            <h1 className="text-xl sm:text-2xl font-bold leading-snug text-[#f0f6fc]">
              {vuln.title}
            </h1>

            <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 font-mono text-[11.5px] text-[#8b949e]">
              <span className="inline-flex items-center gap-1">
                <Code2 className="h-3.5 w-3.5 text-[#00ff9c]/70" /> {fmt(t.codeBlocksUnit, { n: vuln.codeBlocks })}
              </span>
              <span className="inline-flex items-center gap-1">
                <ImageIcon className="h-3.5 w-3.5 text-[#22d3ee]/70" /> {fmt(t.shotsUnit, { n: vuln.images })}
              </span>
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3.5 w-3.5 text-[#fbbf24]/70" /> {fmt(t.minRead, { n: Math.max(1, Math.round(words / 500)) })}
              </span>
              {vuln.year && (
                <span className="inline-flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5 text-[#c084fc]/70" /> {vuln.year}
                </span>
              )}
            </div>

            {/* 操作按钮 */}
            <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-[#21262d] pt-4">
              <button
                type="button"
                onClick={() => toggleRead(vuln.id)}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3.5 py-1.5 text-[12.5px] transition-all ${
                  isRead
                    ? 'border-[#00ff9c]/50 bg-[#00ff9c]/10 text-[#00ff9c]'
                    : 'border-[#30363d] text-[#8b949e] hover:border-[#00ff9c]/40 hover:text-[#c9d4de]'
                }`}
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                {isRead ? t.alreadyRead : t.markRead}
              </button>
              <button
                type="button"
                onClick={() => toggleFav(vuln.id)}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3.5 py-1.5 text-[12.5px] transition-all ${
                  isFav
                    ? 'border-[#fbbf24]/50 bg-[#fbbf24]/10 text-[#fbbf24]'
                    : 'border-[#30363d] text-[#8b949e] hover:border-[#fbbf24]/40 hover:text-[#c9d4de]'
                }`}
              >
                <Star className={`h-3.5 w-3.5 ${isFav ? 'fill-[#fbbf24]' : ''}`} />
                {isFav ? t.favedBtn : t.favBtn}
              </button>
              <CopyLinkButton getPath={() => `/#/vuln/${encodeURIComponent(vuln.id)}`} />
              <button
                type="button"
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="ml-auto inline-flex items-center gap-1 rounded-lg border border-[#30363d] px-3 py-1.5 text-[12.5px] text-[#8b949e] transition-colors hover:text-[#c9d4de] xl:hidden"
              >
                {t.backTop}
              </button>
            </div>
          </header>

          {/* 英文模式：提示笔记正文为中文原文 */}
          {lang === 'en' && (
            <p className="mb-4 flex items-start gap-2 rounded-lg border border-[#fbbf24]/30 bg-[#fbbf24]/8 px-4 py-2.5 text-[12.5px] leading-relaxed text-[#fbbf24]">
              <Globe className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              {t.zhOnlyNote}
            </p>
          )}

          {/* 正文 */}
          <div ref={contentRef} className="rounded-2xl border border-[#21262d] bg-[#161b22] p-5 sm:p-7">
            <MarkdownRender content={vuln.content} />
          </div>

          {/* 同组件推荐 */}
          {related.length > 0 && (
            <section className="mt-6">
              <h2 className="mb-3 font-mono text-[12.5px] tracking-widest text-[#8b949e]">
                {t.relatedTitle}{vuln.component}
              </h2>
              <div className="flex flex-wrap gap-2">
                {related.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => navigate({ name: 'vuln', id: r.id })}
                    className="rounded-lg border border-[#21262d] bg-[#161b22] px-3 py-2 text-left text-[12px] text-[#c9d4de] transition-all hover:border-[#00ff9c]/45 hover:text-[#00ff9c] max-w-full"
                  >
                    <span className="line-clamp-1">{r.title}</span>
                  </button>
                ))}
              </div>
            </section>
          )}

          {/* 上一篇 / 下一篇 */}
          <nav className="mt-8 grid gap-3 border-t border-[#21262d] pt-6 sm:grid-cols-2" aria-label="分页导航">
            {prev ? (
              <button
                type="button"
                onClick={() => navigate({ name: 'vuln', id: prev.id })}
                className="group flex items-center gap-3 rounded-xl border border-[#21262d] bg-[#161b22] p-4 text-left transition-all hover:border-[#00ff9c]/45"
              >
                <ChevronLeft className="h-4 w-4 shrink-0 text-[#8b949e] group-hover:text-[#00ff9c]" />
                <span className="min-w-0">
                  <span className="block font-mono text-[10.5px] text-[#6e7681]">{t.prevLabel}</span>
                  <span className="mt-0.5 block truncate text-[13px] text-[#c9d4de] group-hover:text-[#00ff9c]">
                    {prev.title}
                  </span>
                </span>
              </button>
            ) : (
              <span />
            )}
            {next && (
              <button
                type="button"
                onClick={() => navigate({ name: 'vuln', id: next.id })}
                className="group flex items-center justify-end gap-3 rounded-xl border border-[#21262d] bg-[#161b22] p-4 text-right transition-all hover:border-[#00ff9c]/45"
              >
                <span className="min-w-0">
                  <span className="block font-mono text-[10.5px] text-[#6e7681]">{t.nextLabel}</span>
                  <span className="mt-0.5 block truncate text-[13px] text-[#c9d4de] group-hover:text-[#00ff9c]">
                    {next.title}
                  </span>
                </span>
                <ChevronRight className="h-4 w-4 shrink-0 text-[#8b949e] group-hover:text-[#00ff9c]" />
              </button>
            )}
          </nav>
        </article>

        {/* 目录侧栏（xl 及以上） */}
        <aside className="hidden xl:block">
          <div className="sticky top-20 max-h-[calc(100vh-6rem)] overflow-y-auto pr-1">
            <h2 className="mb-3 flex items-center gap-1.5 font-mono text-[11.5px] tracking-widest text-[#8b949e]">
              <ArrowRight className="h-3 w-3 text-[#00ff9c]" /> {t.tocTitle}
            </h2>
            {toc.length > 0 ? (
              <nav className="flex flex-col" aria-label="页面目录">
                {toc.map((item) => (
                  <a
                    key={item.id}
                    href={`#${item.id}`}
                    onClick={(e) => {
                      e.preventDefault();
                      document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className={`toc-link ${activeId === item.id ? 'active' : ''} ${item.level === 3 ? 'pl-[1.7em]' : ''}`}
                    title={item.text}
                  >
                    <span className="line-clamp-1">{item.text}</span>
                  </a>
                ))}
              </nav>
            ) : (
              <p className="font-mono text-[11px] text-[#6e7681]">{t.tocLoading}</p>
            )}
          </div>
        </aside>
      </div>

      {/* 图片灯箱 */}
      {lightbox && (
        <div
          className="lightbox-overlay"
          onClick={() => setLightbox(null)}
          role="dialog"
          aria-label="查看大图"
        >
          <img src={lightbox} alt="漏洞复现大图" referrerPolicy="no-referrer" />
        </div>
      )}
    </div>
  );
}
