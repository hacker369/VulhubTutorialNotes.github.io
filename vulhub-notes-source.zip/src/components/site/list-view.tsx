'use client';

import { useMemo } from 'react';
import { FilterX, Search, Star } from 'lucide-react';
import { filterVulns, navigate, useAppStore } from '@/lib/store';
import { typeColor } from '@/lib/types';
import { useT, fmt, typeName } from '@/lib/i18n';
import type { LibraryQuery } from '@/lib/types';
import { VulnCard } from '@/components/site/vuln-card';

interface Props {
  query: LibraryQuery;
}

const STATUS_OPTIONS: { value: LibraryQuery['status']; key: 'stAll' | 'stUnread' | 'stRead' | 'stFav'; star?: boolean }[] = [
  { value: '', key: 'stAll' },
  { value: 'unread', key: 'stUnread' },
  { value: 'read', key: 'stRead' },
  { value: 'fav', key: 'stFav', star: true },
];

export function ListView({ query }: Props) {
  const data = useAppStore((s) => s.data);
  const read = useAppStore((s) => s.read);
  const fav = useAppStore((s) => s.fav);
  const lang = useAppStore((s) => s.lang);
  const t = useT();

  const patchQuery = (patch: Partial<LibraryQuery>) => {
    navigate({ name: 'library', query: { ...query, ...patch } });
  };

  const results = useMemo(() => {
    if (!data) return [];
    return filterVulns(data.vulns, query, read, fav, (ty) => typeName(ty, lang));
  }, [data, query, read, fav, lang]);

  const typeCounts = useMemo(() => {
    if (!data) return new Map<string, number>();
    const m = new Map<string, number>();
    data.types.forEach((t) => {
      m.set(
        t,
        data.vulns.filter((v) => v.type === t).length
      );
    });
    return m;
  }, [data]);

  const hasFilter = query.q !== '' || query.type !== '' || query.comp !== '' || query.status !== '';

  if (!data) return null;

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 py-8">
      {/* 页头 */}
      <div className="mb-6">
        <p className="mb-1.5 font-mono text-[11.5px] tracking-[0.25em] text-[#00ff9c]">
          {'// EXPLOIT LIBRARY'}
        </p>
        <h1 className="text-2xl font-bold text-[#f0f6fc]">{t.libTitle}</h1>
        <p className="mt-2 text-[13.5px] text-[#8b949e]">
          {fmt(t.libDesc, { n: data.total })}
        </p>
      </div>

      {/* 搜索框 */}
      <div className="relative mb-4">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8b949e]" />
        <input
          value={query.q}
          onChange={(e) => patchQuery({ q: e.target.value })}
          placeholder={t.searchPh}
          className="h-12 w-full rounded-xl border border-[#30363d] bg-[#161b22] pl-11 pr-11 text-[14px] text-[#e6edf3] placeholder:text-[#6e7681] outline-none transition-all focus:border-[#00ff9c]/60 focus:shadow-[0_0_0_3px_rgba(0,255,156,0.08)]"
          aria-label="搜索漏洞"
        />
        {query.q && (
          <button
            type="button"
            onClick={() => patchQuery({ q: '' })}
            className="absolute right-3 top-1/2 -translate-y-1/2 rounded p-1 text-[#8b949e] hover:text-[#e6edf3]"
            aria-label="清空搜索"
          >
            ✕
          </button>
        )}
      </div>

      {/* 类型筛选 chips */}
      <div className="mb-3 flex gap-2 overflow-x-auto pb-1.5 -mx-1 px-1" role="group" aria-label="漏洞类型筛选">
        <button
          type="button"
          onClick={() => patchQuery({ type: '' })}
          className={`shrink-0 rounded-full border px-3.5 py-1.5 text-[12.5px] transition-all ${
            query.type === ''
              ? 'border-[#00ff9c]/60 bg-[#00ff9c]/10 text-[#00ff9c]'
              : 'border-[#30363d] bg-[#161b22] text-[#8b949e] hover:border-[#484f58] hover:text-[#c9d4de]'
          }`}
        >
          {t.allTypes} <span className="font-mono text-[11px]">{data.total}</span>
        </button>
        {data.types.map((ty) => {
          const c = typeColor(ty);
          const active = query.type === ty;
          return (
            <button
              key={ty}
              type="button"
              onClick={() => patchQuery({ type: active ? '' : ty })}
              className="shrink-0 rounded-full border px-3.5 py-1.5 text-[12.5px] transition-all"
              style={
                active
                  ? { color: c.fg, borderColor: c.border, backgroundColor: c.bg }
                  : { color: '#8b949e', borderColor: '#30363d', backgroundColor: '#161b22' }
              }
            >
              {typeName(ty, lang)} <span className="font-mono text-[11px]">{typeCounts.get(ty) ?? 0}</span>
            </button>
          );
        })}
      </div>

      {/* 组件选择 + 状态筛选 */}
      <div className="mb-6 flex flex-wrap items-center gap-2">
        <select
          value={query.comp}
          onChange={(e) => patchQuery({ comp: e.target.value })}
          className="h-9 rounded-lg border border-[#30363d] bg-[#161b22] px-3 text-[12.5px] text-[#c9d4de] outline-none transition-colors focus:border-[#00ff9c]/60"
          aria-label="按组件筛选"
        >
          <option value="">{t.allComps}（{data.components.length}）</option>
          {data.components.map(([comp, count]) => (
            <option key={comp} value={comp}>
              {comp}（{count}）
            </option>
          ))}
        </select>

        <div className="flex rounded-lg border border-[#30363d] bg-[#161b22] p-0.5" role="group" aria-label="阅读状态筛选">
          {STATUS_OPTIONS.map((o) => (
            <button
              key={o.value}
              type="button"
              onClick={() => patchQuery({ status: o.value })}
              className={`inline-flex items-center gap-1 rounded-[6px] px-3 py-1.5 text-[12px] transition-all ${
                query.status === o.value
                  ? o.value === 'fav'
                    ? 'bg-[#fbbf24]/15 text-[#fbbf24]'
                    : 'bg-[#00ff9c]/12 text-[#00ff9c]'
                  : 'text-[#8b949e] hover:text-[#c9d4de]'
              }`}
            >
              {o.star && <Star className="h-3 w-3" />}
              {t[o.key]}
            </button>
          ))}
        </div>

        {hasFilter && (
          <button
            type="button"
            onClick={() => patchQuery({ q: '', type: '', comp: '', status: '' })}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#30363d] px-3 py-1.5 text-[12px] text-[#8b949e] transition-colors hover:border-[#f87171]/50 hover:text-[#f87171]"
          >
            <FilterX className="h-3.5 w-3.5" />
            {t.clearFilters}
          </button>
        )}

        <span className="ml-auto font-mono text-[12px] text-[#8b949e]">
          <span className="text-[#00ff9c]">{results.length}</span> / {data.total} {t.resultsUnit}
        </span>
      </div>

      {/* 结果网格 */}
      {results.length > 0 ? (
        <div className="grid gap-3 sm:gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {results.map((v) => (
            <VulnCard key={v.id} vuln={v} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-[#30363d] py-20 text-center">
          <p className="font-mono text-[13px] text-[#8b949e]">
            <span className="text-[#00ff9c]">➜</span> {t.noMatch}
          </p>
          <p className="mt-2 text-[12px] text-[#6e7681]">{t.noMatchHint}</p>
          <button
            type="button"
            onClick={() => patchQuery({ q: '', type: '', comp: '', status: '' })}
            className="mt-5 rounded-lg border border-[#00ff9c]/40 bg-[#00ff9c]/5 px-4 py-2 text-[13px] text-[#00ff9c] transition-colors hover:bg-[#00ff9c]/12"
          >
            {t.resetFilters}
          </button>
        </div>
      )}
    </div>
  );
}
