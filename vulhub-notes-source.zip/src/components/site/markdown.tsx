'use client';

import { Children, isValidElement, memo, useState, type ReactElement, type ReactNode } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Check, Copy, Link2 } from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { useT } from '@/lib/i18n';

/** 提取 ReactNode 的纯文本 */
function nodeText(node: ReactNode): string {
  if (node == null || typeof node === 'boolean') return '';
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(nodeText).join('');
  if (isValidElement(node)) {
    const props = node.props as { children?: ReactNode };
    return nodeText(props.children);
  }
  return '';
}

/** 生成标题锚点 id（中文安全 + 去重） */
function makeAnchor(text: string, used: Set<string>): string {
  const base =
    text
      .trim()
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s-]/gu, '')
      .replace(/\s+/g, '-')
      .slice(0, 64) || 'section';
  let id = base;
  let i = 2;
  while (used.has(id)) id = `${base}-${i++}`;
  used.add(id);
  return id;
}

/** 语言别名映射（笔记里常用 plain） */
function normalizeLang(lang: string): string {
  const alias: Record<string, string> = {
    plain: 'text', shell: 'bash', sh: 'bash', zsh: 'bash',
    yml: 'yaml', py: 'python', js: 'javascript', ts: 'typescript',
    html: 'markup', xml: 'markup', md: 'markdown',
  };
  return alias[lang] ?? lang;
}

/** 带复制按钮的代码块 */
function CodeBlock({ code, lang }: { code: string; lang: string }) {
  const [copied, setCopied] = useState(false);
  const t = useT();
  const display = normalizeLang(lang);

  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = code;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  return (
    <div className="code-block">
      <div className="code-block-bar">
        <span className="code-block-lang">{display === 'text' ? 'plain' : display}</span>
        <button
          type="button"
          className={`copy-btn ${copied ? 'copied' : ''}`}
          onClick={onCopy}
          aria-label="复制代码"
        >
          {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
          {copied ? t.copiedCodeBtn : t.copyCodeBtn}
        </button>
      </div>
      <SyntaxHighlighter
        language={display}
        style={oneDark}
        customStyle={{ margin: 0, padding: 0, background: 'transparent' }}
        codeTagProps={{
          style: {
            fontFamily: 'var(--font-geist-mono), ui-monospace, SFMono-Regular, Menlo, monospace',
          },
        }}
        wrapLongLines={false}
      >
        {code}
      </SyntaxHighlighter>
    </div>
  );
}

const MarkdownRender = memo(function MarkdownRender({ content }: { content: string }) {
  const setLightbox = useAppStore((s) => s.setLightbox);
  const usedIds = new Set<string>();

  return (
    <div className="md-body">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          h1: ({ children }) => <h1 id={makeAnchor(nodeText(children), usedIds)}>{children}</h1>,
          h2: ({ children }) => <h2 id={makeAnchor(nodeText(children), usedIds)}>{children}</h2>,
          h3: ({ children }) => <h3 id={makeAnchor(nodeText(children), usedIds)}>{children}</h3>,
          h4: ({ children }) => <h4 id={makeAnchor(nodeText(children), usedIds)}>{children}</h4>,
          pre: ({ children }) => {
            try {
              const child = Children.only(children) as ReactElement<{
                className?: string;
                children?: ReactNode;
              }>;
              const codeText = nodeText(child.props.children).replace(/\n$/, '');
              const m = /language-([\w-]+)/.exec(child.props.className ?? '');
              return <CodeBlock code={codeText} lang={m?.[1] ?? 'text'} />;
            } catch {
              return <pre>{children}</pre>;
            }
          },
          img: ({ src, alt }) => {
            const url = typeof src === 'string' ? src : '';
            if (!url) return null;
            return (
              <img
                src={url}
                alt={alt ?? '漏洞复现截图'}
                loading="lazy"
                referrerPolicy="no-referrer"
                onClick={() => setLightbox(url)}
              />
            );
          },
          a: ({ href, children }) => {
            const ext = typeof href === 'string' && /^https?:\/\//.test(href);
            return (
              <a
                href={href}
                target={ext ? '_blank' : undefined}
                rel={ext ? 'noopener noreferrer' : undefined}
              >
                {children}
              </a>
            );
          },
          table: ({ children }) => (
            <div className="overflow-x-auto">
              <table>{children}</table>
            </div>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
});

export default MarkdownRender;

/** 复制当前页面链接的小按钮（详情页复用） */
export function CopyLinkButton({ getPath }: { getPath: () => string }) {
  const [copied, setCopied] = useState(false);
  const t = useT();
  const onCopy = async () => {
    const url = `${window.location.origin}${getPath()}`;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      /* ignore */
    }
  };
  return (
    <button type="button" className="copy-btn" onClick={onCopy} aria-label="复制链接">
      <Link2 className="h-3 w-3" />
      {copied ? t.copiedBtn : t.shareBtn}
    </button>
  );
}
