import type { NextConfig } from "next";

/*
 * 默认：standalone（本地 dev / 容器部署用）
 * EXPORT_STATIC=1：输出纯静态站点到 out/（GitHub Pages 部署用）
 *   - output: "export"         静态导出
 *   - distDir: ".next-static"  隔离构建产物，不影响正在运行的 dev server
 *   - assetPrefix: "./"        相对资源路径 → 可部署在任意子路径（如 /VulhubTutorialNotes.github.io/）
 *   - images.unoptimized       静态导出需关闭图片优化（站点本身全部用 <img> 外链语雀图床，不受影响）
 */
const isStaticExport = process.env.EXPORT_STATIC === "1";

const baseConfig = {
  typescript: { ignoreBuildErrors: true },
  reactStrictMode: false,
};

const nextConfig: NextConfig = isStaticExport
  ? {
      ...baseConfig,
      output: "export",
      distDir: ".next-static",
      assetPrefix: "./",
      images: { unoptimized: true },
    }
  : {
      ...baseConfig,
      output: "standalone",
    };

export default nextConfig;
